# Handoff Format (다음 단계 입력 요약본)

> ITCONNECT_PROCESS 모든 산출물의 마지막에 부착하는 표준 형식.
> 다음 스킬이 이 요약본을 그대로 입력으로 받아 작업을 시작할 수 있어야 한다.

---

## 표준 구조

```markdown
---

## 다음 단계 입력 요약본 (Handoff Pack)

### 1. 한 줄 정의
[이 산출물을 한 문장으로]

### 2. 잠긴 결정 (Locked)
- [확정된 핵심 결정 5~10개]

### 3. 미해결 / 추후 결정
- [TBD 항목, 각각 "왜 미정인지" 명시]

### 4. 다음 스킬에 전달하는 핵심 변수
- [다음 스킬이 사용할 값들. 예: 타겟 고객, MVP 범위, 기술 제약 등]

### 5. 다음 스킬 호출 안내
다음 단계: [스킬명]
호출 방법: "[정확한 트리거 문구]"
```

---

## 스킬별 핸드오프 변수 매핑

| From | To | 핵심 변수 |
|---|---|---|
| service-ideation | prd-writer | 서비스명, 타겟, 문제, 가치 제안, MVP 범위 3~5개, KPI |
| prd-writer | frd-writer | 필수 기능 목록(우선순위 포함), 사용자 흐름, 권한 정책 |
| frd-writer | trd-writer | 화면별 상태, 비기능 수치, 비동기 처리 요구, 검증 규칙 |
| trd-writer | brand-strategy | 기술 스택, 카테고리(웹/앱/SaaS/교육), 1차 출시 채널 |
| brand-strategy | design-system-builder | 성격 키워드, 톤앤매너, 컬러 방향, 폰트 방향, 금지 인상 |
| design-system-builder | webpage-planner (옵션) | 토큰, 컴포넌트 시스템, 안티패턴, 랜딩 패턴 |
| (전체) | project-qa | 위 모든 산출물 |

---

## 트리거 문구 표준

다음 스킬 호출 시 사용자가 입력할 정확한 문구:

| 스킬 | 트리거 문구 |
|---|---|
| prd-writer | "PRD 작성해줘" |
| frd-writer | "FRD 작성해줘" |
| trd-writer | "TRD 작성해줘" |
| brand-strategy | "브랜드 전략 수립해줘" |
| design-system-builder | "디자인 시스템 만들어줘" |
| webpage-planner | "페이지 기획해줘" (옵션, 소개·설득 페이지가 필요할 때만) |
| project-qa | "최종 검수해줘" |

---

## 금지 사항

- 산출물 본문을 요약본에 그대로 복사 금지 (핵심 변수만)
- "TBD" 항목 5개 초과 금지 (의사결정 회피)
- 핸드오프 변수에 추정값을 넣으면 반드시 "(추정)" 표시
