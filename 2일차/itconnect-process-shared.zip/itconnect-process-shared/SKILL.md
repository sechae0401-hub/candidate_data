---
name: itconnect-process-shared
description: >
  ITCONNECT_PROCESS 파이프라인의 모든 스킬이 공유하는 공통 운영 모듈. 직접 트리거되지 않으며,
  service-ideation, prd-writer, frd-writer, trd-writer, brand-strategy,
  design-system-builder, webpage-planner, project-qa 스킬이 자동으로 참조한다.
  사용자가 직접 호출하지 않는다.
---

# ITCONNECT_PROCESS Shared Module

ITCONNECT_PROCESS 8개 스킬이 공유하는 운영 자산. 직접 트리거되지 않는다.

## 파일 구성과 로드 시점

| 파일 | 언제 로드 | 용도 |
|---|---|---|
| `core-rules.md` | **모든 ITCONNECT_PROCESS 스킬 실행 시 필수** | 5대 baseline 규칙 |
| `qa-pattern.md` | 질의응답형 스킬만 (project-qa 제외) | A/B/C/D 선택형 + 풀 사이클 + 미니 강의 패턴 |
| `non-dev-glossary.md` | 어려운 용어 첫 등장 시 참조 | 비개발자용 용어 풀이 카탈로그 (50+) |
| `handoff-format.md` | 모든 스킬 마지막 단계 | 다음 단계 입력 요약본 표준 |
| `adversarial-review.md` | 산출물 확정 직전 | 다음 단계 소비자 관점 검토 |
| `expert-panel-mode.md` | 사용자가 "패널 모드/파티 모드" 요청 시 | 전문가 패널·파티 모드 |
| `scripts/structure_check.py` | 문서 구조 자동 검증 시 | PRD/FRD/TRD 섹션 누락 체크 |

## 각 스킬에서 참조하는 방법

스킬 SKILL.md의 첫 단계에서 아래 패턴을 사용한다:

```
1. /mnt/skills/user/itconnect-process-shared/core-rules.md 읽기 (필수)
2. 질의응답형이면 qa-pattern.md 추가 로드
3. 어려운 용어 등장 시 non-dev-glossary.md 참조 (또는 동급 인라인 풀이)
4. 산출물 확정 직전 adversarial-review.md 로드
5. 사용자가 패널/파티 모드 요청 시 expert-panel-mode.md 로드
```

**원칙**: 필요할 때만 로드한다. 모든 파일을 매번 로드하지 않는다.
