#!/usr/bin/env python3
"""기획 문서 구조 완성도 검증 (AIPM 스킬 공통)

사용법:
  python structure_check.py --file prd.md --type prd
  python structure_check.py --file frd.md --type frd
  python structure_check.py --file trd.md --type trd

종료코드: 0=PASS, 1=FAIL, 2=ERROR
"""
import argparse, json, re, sys

REQUIRED_SECTIONS = {
    "prd": ["목표","타겟 사용자","핵심 기능","사용자 흐름","우선순위","비기능 요구사항","MVP 범위"],
    "frd": ["화면 목록","화면별 기능","상태 정의","권한","API","검증 규칙"],
    "trd": ["아키텍처","기술 스택","데이터 모델","API 설계","인프라","배포"],
    "service": ["고객 정의","문제 정의","솔루션","비즈니스 모델","경쟁 분석","MVP"],
    "brand": ["브랜드 정체성","포지셔닝","톤앤매너","네이밍","시각 언어"],
}

def check_structure(content, doc_type):
    results, failed, warnings = [], [], []
    lines = content.split("\n")
    headings = [l.strip().lstrip("#").strip() for l in lines if l.strip().startswith("#")]
    headings_lower = " ".join(headings).lower()

    required = REQUIRED_SECTIONS.get(doc_type, [])
    missing = [s for s in required if s.lower() not in headings_lower and s not in content]
    if not missing:
        results.append(("required_sections", True, f"필수 섹션 {len(required)}개 모두 존재"))
    else:
        results.append(("required_sections", False, f"누락: {missing}"))
        failed.append({"item":"required_sections","reason":f"누락: {', '.join(missing)}"})

    empty_sections = []
    for i, line in enumerate(lines):
        if line.strip().startswith("## "):
            j = i + 1
            has_content = False
            while j < len(lines):
                if lines[j].strip().startswith("#"): break
                if lines[j].strip() and not lines[j].strip().startswith("---"):
                    has_content = True; break
                j += 1
            if not has_content:
                empty_sections.append(line.strip())
    if not empty_sections:
        results.append(("no_empty", True, "빈 섹션 없음"))
    else:
        results.append(("no_empty", False, f"빈 섹션 {len(empty_sections)}개"))
        failed.append({"item":"no_empty","reason":f"빈 섹션: {empty_sections[:3]}"})

    tbd_patterns = re.findall(r'(?:TBD|미정|추후 결정|TODO|추후|나중에)', content, re.I)
    if len(tbd_patterns) <= 3:
        results.append(("tbd_count", True, f"TBD/미정 {len(tbd_patterns)}개"))
    else:
        results.append(("tbd_count", False, f"TBD/미정 {len(tbd_patterns)}개 — 3개 이하 권장"))
        warnings.append({"item":"tbd_count","note":f"{len(tbd_patterns)}개 미확정 항목"})

    has_summary = bool(re.search(r'다음 단계|입력 요약|요약본|next step', content, re.I))
    if has_summary:
        results.append(("next_step", True, "다음 단계 요약본 존재"))
    else:
        results.append(("next_step", False, "다음 단계 입력 요약본 누락"))
        failed.append({"item":"next_step","reason":"문서 마지막에 '다음 단계 입력 요약본' 추가 필요"})

    if doc_type in ("prd","frd"):
        has_priority = bool(re.search(r'필수|선택|후순위|P[0-3]|Must|Should|Could|높음|중간|낮음', content))
        if has_priority:
            results.append(("priority", True, "우선순위 라벨 존재"))
        else:
            results.append(("priority", False, "우선순위 라벨 미발견"))
            warnings.append({"item":"priority","note":"기능별 우선순위 추가 권장"})

    total = len(results)
    passed = sum(1 for _,o,_ in results if o)
    status = "PASS" if not failed else "FAIL"
    return {"total":total,"passed":passed,"failed":failed,"warnings":warnings,"status":status,
            "details":[{"item":i,"passed":o,"message":m} for i,o,m in results]}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--file", required=True)
    p.add_argument("--type", default="prd", choices=["prd","frd","trd","service","brand"])
    args = p.parse_args()
    try:
        content = open(args.file,"r",encoding="utf-8").read()
    except FileNotFoundError:
        print(json.dumps({"error":f"파일 없음: {args.file}"},ensure_ascii=False)); sys.exit(2)
    r = check_structure(content, args.type)
    print(json.dumps(r,ensure_ascii=False,indent=2))
    print(f"\nStructure: {r['passed']}/{r['total']} [{r['status']}]",file=sys.stderr)
    for f in r.get('failed',[]): print(f"  ❌ {f['item']}: {f['reason']}",file=sys.stderr)
    for w in r.get('warnings',[]): print(f"  ⚠️ {w['item']}: {w['note']}",file=sys.stderr)
    sys.exit(0 if r['status']=="PASS" else 1)

if __name__=="__main__": main()
