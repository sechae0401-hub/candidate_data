# TRD Output Template (Two-File Structure v2)

> 이 템플릿은 두 개의 산출물을 생성한다. 기술 결정을 표 나열식이 아닌 "왜 이걸 골랐는가" 산문 + 비교표 + 비용 추정으로 작성한다.

---

## 산출물 구조

TRD 작성 완료 시 **두 개의 파일**이 `/mnt/user-data/outputs/`에 저장된다.

| 파일 | 파일명 | 독자 | 분량 | 성격 |
|---|---|---|---|---|
| **본문** | `trd-{서비스명}-{YYYYMMDD}.md` | CEO·CTO·외부 이해관계자·외주사 | 8~12페이지 | 처음부터 끝까지 읽는 기술 결정 보고서 |
| **핸드오프** | `trd-{서비스명}-{YYYYMMDD}-handoff.md` | Claude Code·DevOps·개발자 | 8~14페이지 | SQL 전문·환경변수·설정 파일·정밀 데이터 |

두 파일 모두 `present_files`로 전달한다. 본문 → 핸드오프 순서.

---

## 작성 원칙 (두 파일 모두 적용)

1. **산문 → 비교표 → 코드 순서**: 모든 기술 결정은 "왜 이걸 골랐는가" 산문 → 옵션 비교표 → (필요 시) 설정 스니펫.
2. **본문에는 코드 전문 없음**: CREATE TABLE 전문, dockerfile, yaml 설정, env 파일은 본문에 등장 금지. 모두 핸드오프로 분리.
3. **각 결정마다 비용·마이그레이션 명시**: "월 비용 추정 4단계" + "나중에 바꾸려면 얼마나 어려운가" 의무.
4. **mermaid 의무**: 3개 위치에서 mermaid 사용 (아키텍처 모듈 분해·데이터 흐름·배포 구조).
5. **Executive Summary는 한 문단**: 아키텍처·핵심 스택·월 비용·기술 리스크를 산문으로 압축.
6. **벤더 락인 명시**: 특정 서비스 의존도와 전환 난이도를 명시.

---

# PART A. 본문 파일 표준 구조

파일명: `trd-{서비스명}-{YYYYMMDD}.md`

````markdown
# [서비스명] TRD

> 작성일: YYYY-MM-DD · 버전: v1.0
> PRD: `prd-[서비스명]-[YYYYMMDD].md` v[버전]
> FRD: `frd-[서비스명]-[YYYYMMDD].md` v[버전]
> 다음 단계: 브랜드 전략 (`trd-{이름}-{날짜}-handoff.md` 참조)

---

## 1. 한 문단 요약

[1~2 문단 산문. 항목 나열 금지.

산문 1문단: "이 서비스는 [아키텍처]로 구성되며, 프론트엔드는 [X],
백엔드는 [Y], 데이터베이스는 [Z]를 사용한다. 이 조합을 선택한
가장 큰 이유는 [...]이다." 자연스럽게.

산문 2문단: 월 운영비 추정 4단계와 가장 큰 기술 리스크 2~3개를
산문으로 풀어쓴다.]

---

## 2. 어떤 그림으로 만드는가 (아키텍처)

[1~2 문단 산문 도입: 전체 아키텍처를 한 문단으로 설명. "모듈러 모놀로식이며 ..." 자연스럽게.]

### 2.1 아키텍처 결정 — 모듈러 모놀로식

[2~3 문단 산문: 왜 모듈러 모놀로식을 골랐는가. MSA·서버리스 등 대안과의 비교.
"1~3인 팀이 3개월 안에 출시해야 하는 상황에서 MSA를 도입하면 ..." 같은
실용적 근거.]

| 항목 | 모듈러 모놀로식 (선택) | MSA | 서버리스 |
|---|---|---|---|
| 초기 개발 속도 | 빠름 | 느림 | 중간 |
| 운영 부담 | 낮음 | 높음 | 중간 |
| 1~3인 팀 적합도 | 매우 적합 | 부적합 | 중간 |
| 비용 (월) | $20~50 | $200~ | 사용량 기반 |

### 2.2 모듈 분해

[1 문단 산문: 어떤 부서·역할로 모듈을 나눴는지.]

```mermaid
graph TD
    subgraph "[서비스명]"
        AUTH[auth - 인증/회원]
        CORE[core - 핵심 기능]
        BILL[billing - 결제]
        ADMIN[admin - 관리자]
    end
    AUTH --> DB[(DB)]
    CORE --> DB
    BILL --> DB
    ADMIN --> DB
```

### 2.3 모듈 간 통신

[1 문단 산문: 모듈끼리 어떻게 데이터를 주고받는가. 함수 호출·이벤트·메시지 큐 등.]

---

## 3. 어떤 도구로 만드는가 (기술 스택)

[1 문단 도입: 이 챕터에서 6개 영역(프론트엔드·백엔드·DB·인증·인프라·외부)의 결정을 본다는 안내.]

### 3.1 프론트엔드

[1~2 문단 산문: 어떤 프레임워크·언어·UI 라이브러리를 골랐고 왜 골랐는가.
"Next.js를 선택한 가장 큰 이유는 ..." 자연스럽게.]

📚 **미니 강의 (필요 시)**: [비개발자가 이해해야 할 개념 한 가지를 일상 비유로]

| 영역 | 선택 | 대안 | 선택 이유 (한 줄) |
|---|---|---|---|
| 프레임워크 | Next.js 14 | Remix, SvelteKit | 한국 개발자 풀 가장 큼, AI 도구 호환 |
| 언어 | TypeScript | JavaScript | 타입 검사로 AI 코드 실수 감소 |
| UI 컴포넌트 | shadcn/ui | MUI, Chakra | 디자인 일관성 + 복사 사용 |
| 스타일링 | Tailwind CSS | CSS Modules | 빠른 개발 속도 |

> 정밀한 버전 명시(`next@14.2.x` 등)와 package.json 예시는 핸드오프 §2 참조.

### 3.2 백엔드

[1~2 문단 산문]

| 영역 | 선택 | 대안 | 선택 이유 |
|---|---|---|---|
| 런타임 | Node.js | Python, Go | 프론트와 같은 언어, 풀스택 단일화 |
| API 방식 | REST | GraphQL, tRPC | 표준성, 캐싱 용이 |

### 3.3 데이터베이스

[1~2 문단 산문]

📚 **미니 강의**: 관계형 vs NoSQL 차이를 일상 비유로 (예: "관계형은 정해진 양식의 서류함, NoSQL은 자유 형식의 메모장")

| 영역 | 선택 | 대안 | 선택 이유 |
|---|---|---|---|
| 메인 DB | PostgreSQL | MySQL, MongoDB | 표준 SQL, JSON 컬럼 지원 |
| ORM | Prisma | TypeORM, Drizzle | TypeScript 호환 최고 |
| 캐시 | (없음) / Redis | Memcached | 초기엔 불필요, 트래픽 증가 시 |

> 정밀한 ERD·테이블 정의·인덱스는 핸드오프 §3 참조.

### 3.4 인증

[1~2 문단 산문: 왜 외부 서비스를 쓰는가, 어떤 서비스를 골랐는가.]

| 영역 | 선택 | 대안 | 선택 이유 | 비용 |
|---|---|---|---|---|
| 인증 서비스 | Clerk | NextAuth, Supabase Auth | UI까지 한 번에, 빠른 출시 | 월 $25부터 |

### 3.5 인프라

[1~2 문단 산문: 호스팅·도메인·CDN·CI/CD를 묶어서 설명.]

| 영역 | 선택 | 대안 | 선택 이유 | 비용 |
|---|---|---|---|---|
| 호스팅 (FE/BE) | Vercel | Netlify, AWS | Next.js 매끄러움 | 베타 무료, v1 $20 |
| 데이터베이스 호스팅 | Supabase | Neon, RDS | DB + Storage + Auth 통합 | 베타 무료, v1 $25 |
| 도메인 | Cloudflare | Namecheap | 무료 SSL + CDN | 연 $10 |

### 3.6 외부 서비스

[1 문단 산문]

| 용도 | 선택 | 대안 | 비용 |
|---|---|---|---|
| LLM | Gemini 2.5 Flash | Claude, GPT-4o | 무료 티어 1,500/일 |
| 결제 | Stripe (예정) | Toss, KCP | 수수료 2.9% |
| 메일 발송 | Resend | SendGrid | 월 3,000건 무료 |
| 분석 | GA4 | PostHog | 무료 |

> 각 외부 서비스의 API 키·환경변수·설정 가이드는 핸드오프 §6 참조.

---

## 4. 데이터가 어떻게 흐르는가

[1~2 문단 산문: 사용자 요청이 시스템 안에서 어떻게 흘러가는지.]

```mermaid
sequenceDiagram
    participant U as 사용자
    participant FE as Next.js
    participant BE as API Route
    participant DB as PostgreSQL
    participant EXT as 외부 API

    U->>FE: 페이지 요청
    FE->>BE: 데이터 요청
    BE->>EXT: AI 호출
    EXT-->>BE: 응답
    BE->>DB: 저장
    DB-->>BE: 확인
    BE-->>FE: 결과
    FE-->>U: 렌더링
```

### 4.1 데이터 모델 (개요)

[1 문단 산문: 어떤 엔티티가 있고 어떻게 관계되는가.]

```mermaid
erDiagram
    USERS ||--o{ LEADS : creates
    LEADS ||--o{ MESSAGES : has
    LEADS {
        uuid id PK
        text company_name
        text status
    }
```

> 전체 CREATE TABLE 문, RLS 정책, 인덱스는 핸드오프 §3 참조.

---

## 5. 안전을 어떻게 지키는가 (보안)

[1~2 문단 산문 도입: 가장 중요한 보안 결정을 본다는 안내.]

### 5.1 인증·인가
[1~2 문단 산문: 어떻게 사용자를 식별하고 권한을 분리하는가.]

### 5.2 자격증명 저장
[1 문단 산문: API 키·비밀번호 같은 민감 정보를 어떻게 저장하는가.]

### 5.3 데이터 보호
[1 문단 산문: HTTPS·암호화·백업·RLS 등.]

> 정밀한 RLS 정책 SQL·환경변수 목록·보안 체크리스트는 핸드오프 §4·§5 참조.

---

## 6. 얼마가 드는가 (비용·운영)

[1~2 문단 산문 도입: 비용을 4단계로 추정하는 이유, 운영 부담 개요.]

### 6.1 월 운영비 추정 (4단계)

| 단계 | 사용자 규모 | 월 비용 추정 | 주요 비용 |
|---|---|---|---|
| 개발/베타 | 본인 + 테스터 | $0~10 | 도메인만 |
| v1 | DAU 100~1k | $50~100 | Vercel + Supabase + Clerk |
| 성장 | DAU 1k~10k | $200~500 | DB 업그레이드, CDN 추가 |
| 스케일 | DAU 10k+ | $1,000~ | 전용 서버 검토 시점 |

### 6.2 운영 부담 (1인 가정)

[1 문단 산문: 어떤 운영 부담이 있는지. 모니터링·장애 대응·백업 등.]

### 6.3 3개월 출시 가능 여부

[1 문단 산문: ✅ 또는 ⚠️ 판정 + 근거.]

---

## 7. 무엇이 위험한가 (리스크·마이그레이션)

[1~2 문단 산문 도입]

### 7.1 가장 큰 기술 리스크 2~3개

- **[리스크 1]**: [설명]. → [대응 또는 모니터링 방법].
- **[리스크 2]**: [설명]. → [대응].

### 7.2 벤더 락인과 마이그레이션 경로

[1 문단 산문: 어떤 서비스에 의존하고, 나중에 떼어내려면 얼마나 어려운가.]

| 서비스 | 의존도 | 전환 난이도 | 전환 시 작업량 |
|---|---|---|---|
| Vercel | 호스팅 | 중 | 1주 (Dockerfile 작성) |
| Supabase | DB + Auth | 높음 | 2~4주 (RLS 재구성) |
| Clerk | 인증 | 중 | 1~2주 |

---

## 부록 A. 적대적 검토 결과

```
━━━ 🔍 적대적 검토 ━━━
검토 관점: PM + Dev (브랜드/디자인 단계 진입 가능 여부)
검토 대상: [서비스명] TRD v1.0

🔴 HIGH: [발견]
🟡 MEDIUM: [발견]
🟢 LOW: [발견]

━━━ 요약 ━━━
🔴 HIGH: N건 / 🟡 MEDIUM: N건 / 🟢 LOW: N건
진행 판정: [...]
━━━━━━━━━━━━━━━━━
```
````

---

# PART B. 핸드오프 파일 표준 구조

파일명: `trd-{서비스명}-{YYYYMMDD}-handoff.md`

````markdown
# [서비스명] TRD - AI 입력용 핸드오프 팩

> 본문: `trd-[서비스명]-[YYYYMMDD].md`
> 사용처: Claude Code 시스템 프롬프트, DevOps 환경 구성, 외주 RFP
> 성격: 정밀 데이터 카탈로그. 부분 참조용.

---

## 1. 잠긴 결정 (Locked Decisions)

- 아키텍처: 모듈러 모놀로식 (auth/core/billing/admin)
- 프론트엔드: Next.js 14.2.x + TypeScript + Tailwind + shadcn/ui
- 백엔드: Node.js 20 + REST API (Route Handlers)
- DB: PostgreSQL 15 + Prisma ORM
- 인증: Clerk
- 호스팅: Vercel + Supabase
- 도메인: Cloudflare DNS

---

## 2. package.json 핵심 의존성

```json
{
  "dependencies": {
    "next": "^14.2.0",
    "react": "^18.3.0",
    "typescript": "^5.4.0",
    "prisma": "^5.10.0",
    "@clerk/nextjs": "^5.0.0",
    "tailwindcss": "^3.4.0"
  }
}
```

---

## 3. 데이터베이스 (정밀)

### 3.1 ERD

```mermaid
erDiagram
    [전체 엔티티 + 관계]
```

### 3.2 CREATE TABLE 전문

```sql
CREATE TABLE users (...);
CREATE TABLE leads (...);
```

### 3.3 RLS 정책

```sql
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
CREATE POLICY ...;
```

### 3.4 인덱스

```sql
CREATE INDEX idx_leads_user_id ON leads(user_id);
```

### 3.5 Prisma schema.prisma

```prisma
model User {
  id    String @id @default(uuid())
  email String @unique
  leads Lead[]
}
```

---

## 4. 보안 정책 상세

### 4.1 인증·인가
- [정책 상세]

### 4.2 데이터 암호화
- [정책 상세]

### 4.3 API Rate Limiting
- [정책 상세]

---

## 5. 환경변수 목록 (.env.example)

```bash
# 인증
CLERK_SECRET_KEY=
CLERK_PUBLISHABLE_KEY=

# DB
DATABASE_URL=
DIRECT_URL=

# 외부 API
GEMINI_API_KEY=
RESEND_API_KEY=

# 호스팅
VERCEL_TOKEN=
```

각 변수의 발급 위치·용도·민감도는 §6 참조.

---

## 6. 외부 서비스 가입 가이드

### 6.1 Clerk
- 가입: clerk.com
- 무료 한도: MAU 10,000
- 필수 설정: [...]
- 핵심 환경변수: CLERK_SECRET_KEY, CLERK_PUBLISHABLE_KEY

### 6.2 Supabase
[동일 구조]

### 6.3 Gemini API
[동일 구조]

---

## 7. 배포 (CI/CD)

### 7.1 GitHub Actions (.github/workflows/deploy.yml)

```yaml
[전체 워크플로우]
```

### 7.2 Vercel 환경변수 설정 체크리스트
- [ ] CLERK_SECRET_KEY (Production)
- [ ] DATABASE_URL (Production + Preview)

### 7.3 도메인 연결
[상세 단계]

---

## 8. 모니터링·로깅

- 에러 추적: [도구]
- 사용자 분석: [도구]
- 서버 메트릭: [도구]
- 로그 보존 기간: [...]

---

## 9. NFR 정밀 수치

| 항목 | 요구사항 | 측정 방법 | 알람 임계값 |
|---|---|---|---|
| 응답 속도 | p95 < 500ms | Vercel Analytics | 1초 초과 |
| 가용성 | 99.5% | UptimeRobot | 5분 다운 |
| DB 쿼리 | p95 < 100ms | Supabase Dashboard | 500ms 초과 |

---

## 10. 마이그레이션 경로 (벤더 락인 해소)

| 서비스 | 전환 시 작업 |
|---|---|
| Vercel → AWS EC2 | Dockerfile 작성, GitHub Actions 변경 |
| Clerk → Auth.js | 사용자 데이터 이관 스크립트 |
| Supabase → RDS | RLS → 애플리케이션 레벨 권한 검사 재구현 |

---

## 11. AI 바이브코딩 호환성 체크

- [ ] 모든 결정에 명확한 라이브러리 버전 명시
- [ ] DB 스키마 SQL + Prisma schema 모두 포함
- [ ] 환경변수 목록 .env.example 형식
- [ ] CI/CD 워크플로우 yaml 포함
- [ ] 가입·설정 가이드 외부 서비스별 포함

---

## 12. 다음 스킬 호출

**다음 단계**: brand-strategy
**호출 방법**: `"브랜드 전략 수립해줘"`
**brand-strategy에 제공할 입력**:
1. PRD 본문 + PRD 핸드오프
2. FRD 본문 + FRD 핸드오프
3. TRD 본문 (`trd-{이름}-{날짜}.md`)
4. TRD 핸드오프 (본 파일)
````

---

## Mermaid 다이어그램 사용 가이드

본 템플릿이 의무화하는 3개 mermaid 위치.

| 위치 | 다이어그램 | 용도 |
|---|---|---|
| §2.2 모듈 분해 | `graph TD` (서브그래프 포함) | 모듈 구조와 DB 연결 |
| §4 데이터 흐름 | `sequenceDiagram` | 컴포넌트 간 호출 |
| §4.1 데이터 모델 (개요) | `erDiagram` | 핵심 엔티티 관계 |

---

## 본문 ↔ 핸드오프 분리 매핑표

| 기존 TRD 항목 | 본문 배치 | 핸드오프 배치 |
|---|---|---|
| 아키텍처 선택 산문 + 비교표 | §2.1 | — |
| 모듈 분해 mermaid | §2.2 | — |
| 기술 스택 선택 산문 + 비교표 | §3 | — |
| 정밀 라이브러리 버전 (package.json) | 본문 제외 | §2 |
| ERD mermaid (개요) | §4.1 | §3.1 (상세) |
| CREATE TABLE 전문 | 본문 제외 | §3.2 |
| RLS 정책 SQL | 본문 제외 | §3.3 |
| Prisma schema.prisma | 본문 제외 | §3.5 |
| 보안 정책 산문 요약 | §5 | §4 정밀 |
| 환경변수 목록 (.env) | 본문 제외 | §5 |
| 외부 서비스 가입 가이드 | §3.6 요약 표 | §6 정밀 |
| GitHub Actions yaml | 본문 제외 | §7.1 |
| 비용 4단계 추정 | §6.1 | — |
| 마이그레이션 경로 | §7.2 요약 표 | §10 정밀 |
| NFR 수치 | 본문 미언급 | §9 |

---

## 작성 순서

1. **본문 먼저** 작성: §1 → §2 → §3 → §4 → §5 → §6 → §7 → 부록 A
2. **핸드오프** 작성: §1 잠긴 결정 → §2~§10 정밀 데이터 → §11~§12 다음 단계
3. 두 파일 `/mnt/user-data/outputs/`에 저장
4. `present_files`에 본문 → 핸드오프 순서로 전달
5. 다음 단계 안내: "브랜드 전략 시 PRD·FRD·TRD 두 파일씩 = 총 6개 입력"
