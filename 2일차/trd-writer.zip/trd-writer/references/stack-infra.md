# Stack: Infrastructure (인프라 결정)

> 💡 어려운 용어 첫 등장 시 `itconnect-process-shared/non-dev-glossary.md` 풀이를 인라인으로 동반한다 (별도 박스 금지, 본문 흐름 안에 자연스럽게).


> 비개발자에게 매번 옵션을 비교해 설명하고 추천한다.

---

## 결정 항목

1. 호스팅 (배포 + 도메인 + SSL)
2. 도메인 등록
3. CDN / 정적 자산
4. 모니터링 / 에러 추적
5. CI/CD

---

## 1. 호스팅

### 비개발자에게 설명

```
호스팅은 "내 서비스를 인터넷에 공개하는 서버 임대"입니다.
- 직접 서버를 사면 운영 부담이 큽니다
- 클라우드 서비스가 자동으로 관리해주는 방식이 표준
```

### 옵션 비교

| 옵션 | 비교 | 무료 한도 | 유료 시작 |
|---|---|---|---|
| **Vercel** | ✅ Next.js 최적, 1클릭 배포 | Hobby 무료 | $20/월 |
| Railway | 다양한 언어 지원 | $5 크레딧 | $5+ |
| Fly.io | 글로벌 엣지, Docker 기반 | 제한적 무료 | $5+ |
| AWS Amplify | AWS 통합 | 12개월 무료 | $10+ |
| Cloudflare Pages | 정적 사이트 위주 | 매우 관대 | $20+ |
| 자체 서버 (VPS) | ❌ 운영 부담 | - | $5+ |

**추천**: Vercel (Next.js 기준)
**이유**:
- Git 푸시만으로 자동 배포
- 무료 도메인 (서비스명.vercel.app)
- 무료 SSL
- 무료 CDN 포함
- 1클릭 롤백

**비개발자 설명**:
```
Vercel은 GitHub와 연결만 하면 자동 배포되는 호스팅입니다.
서버, SSL, CDN을 다 알아서 처리합니다. 1인이 운영하기 최적.
무료로 시작 가능하고, 트래픽 늘면 자동으로 확장됩니다.
```

---

## 2. 도메인 등록

| 옵션 | 가격 (.com) | 추천 |
|---|---|---|
| **Cloudflare Registrar** | ✅ 도매가 ($9~10/년) | ✅ |
| Namecheap | $10~15/년 | 좋음 |
| GoDaddy | $15+ | ❌ 비쌈 |
| 가비아 | 한국어 지원 | 한국 결제 편하면 |

**추천**: Cloudflare Registrar (도매가 + Cloudflare DNS 통합)

---

## 3. CDN / 정적 자산

| 옵션 | 추천 |
|---|---|
| **Vercel 내장** | ✅ Vercel 사용 시 자동 |
| Cloudflare | Vercel 외에서 사용 시 |
| AWS CloudFront | 엔터프라이즈 |

**추천**: Vercel 내장 (별도 설정 불필요)

### 이미지 / 파일 업로드

| 옵션 | 추천 시점 |
|---|---|
| **Supabase Storage** | ✅ Supabase 사용 시 |
| Cloudinary | 이미지 자동 최적화 |
| AWS S3 | 대용량 |
| Vercel Blob | Vercel 통합 |

**추천**: Supabase Storage (DB와 한 곳)

---

## 4. 모니터링 / 에러 추적

### 비개발자에게 설명

```
서비스를 운영하다 보면 어디서 에러가 났는지 알아야 합니다.
사용자가 "안 돼요"라고 했을 때 어디가 막혔는지 추적 가능해야 함.
```

| 옵션 | 무료 한도 | 추천 |
|---|---|---|
| **Sentry** | 5k 이벤트/월 | ✅ 표준. 에러 추적 |
| **Vercel Analytics** | 무료 (Vercel 사용 시) | ✅ 페이지 성능 |
| **PostHog** | 1M 이벤트/월 무료 | ✅ 사용자 분석 + 세션 리플레이 |
| Datadog | 14일 무료 | 엔터프라이즈 |
| New Relic | 100GB 무료 | 백엔드 모니터링 |

**v1 추천 조합**:
- 에러: Sentry (무료)
- 성능: Vercel Analytics (Vercel Pro 포함)
- 사용자 분석: PostHog (무료 한도 충분)

---

## 5. CI/CD

| 옵션 | 추천 |
|---|---|
| **Vercel 내장** | ✅ Vercel 사용 시 자동 |
| GitHub Actions | 커스텀 워크플로우 필요 시 |
| GitLab CI | GitLab 사용 시 |

**추천**: Vercel 내장 (별도 설정 불필요)

---

## 표준 추천 인프라 (요약)

```
호스팅:    Vercel (Hobby 무료 → Pro $20/월)
도메인:    Cloudflare Registrar ($10/년)
DB:        Supabase (Free → Pro $25/월)
Storage:   Supabase Storage
에러:      Sentry (무료)
분석:      PostHog + Vercel Analytics
CI/CD:     Vercel 자동
```

---

## 비용 추정 (월 기준)

| 단계 | 호스팅 | DB | 도메인 | 모니터링 | 합계 |
|---|---|---|---|---|---|
| 개발 | 무료 | 무료 | $1 | 무료 | $1 |
| 베타 (DAU 100) | 무료 | 무료 | $1 | 무료 | $1 |
| v1 (DAU 1,000) | $20 | $25 | $1 | 무료 | **$46** |
| 성장 (DAU 10,000) | $50 | $50 | $1 | $26 | **$127** |

연간 환산: v1 출시 후 월 $50 정도. **연 60만원으로 운영 가능.**

---

## 벤더 락인 평가

**Vercel + Supabase 조합의 락인 수준**:
- 코드: 90% 다른 곳으로 이전 가능 (Next.js는 어디서나 작동)
- DB: 100% 이전 가능 (PostgreSQL 표준)
- 인증: Clerk 사용 시 70% 이전 가능, NextAuth 사용 시 100%

**원칙**: 락인을 두려워해서 더 어려운 길을 가지 않는다. Vercel을 떠나야 할 정도로 커지면 그때 결정.

---

## 사용자에게 묻는 1차 질문

```
Q1. 인프라는 위 표준 추천(Vercel + Supabase + Cloudflare 도메인)으로 가시겠습니까?
A. 표준 추천대로
B. AWS / GCP 사용 의무 (기업 정책 등)
C. 한국 서버 의무 (법적 이유)
D. 기타

Q2. 에러 추적 / 분석 도구는?
A. 표준 (Sentry + PostHog + Vercel Analytics)
B. 무료만 (Vercel Analytics만)
C. 모두 다 도입 후 결정

이유: 에러 추적 없이 운영하면 사용자 신고에만 의존하게 됩니다.
Sentry 무료 한도면 v1엔 충분합니다.
```
