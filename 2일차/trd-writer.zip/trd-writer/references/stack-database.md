# Stack: Database (데이터베이스 결정)

> 비개발자에게 매번 옵션을 비교해 설명하고 추천한다.

---

## 결정 항목

1. 데이터베이스 종류 (관계형 vs 문서형)
2. 호스팅 방식 (Managed vs Self-host)
3. ORM 선택
4. 캐시 / 검색 (필요한 경우)

---

## 1. 데이터베이스 종류

데이터베이스(DB, 사용자 정보·주문·콘텐츠를 저장하는 창고)는 크게 두 종류로 나뉜다.

- **관계형(SQL)**: 표 형태 데이터, 정합성 중요. 회원·결제·주문에 적합
- **문서형(NoSQL)**: JSON(키-값 데이터 형식) 형태 데이터, 유연성 중요. 로그·캐시에 적합

99% 서비스는 관계형 1개면 충분하다.

### 옵션 비교

| 옵션 | 종류 | 추천 시점 |
|---|---|---|
| **PostgreSQL** | 관계형 (가장 널리 쓰는 무료 DB, "포스트그레스" 발음) | ✅ 표준. 거의 모든 경우 |
| MySQL | 관계형 (PostgreSQL과 양대 산맥) | PostgreSQL 대안. 한국 기존 시스템 |
| SQLite | 관계형 (파일 1개로 동작) | 매우 작은 서비스, 개발용 |
| MongoDB | 문서형 (가장 유명한 NoSQL) | 데이터 구조가 자주 바뀌는 경우 |
| Firestore | 문서형 (Google Firebase 제품) | 모바일 앱 |
| DynamoDB | 키-값 (AWS 제품) | 대규모 트래픽 (AWS 종속) |

**추천**: PostgreSQL
**이유**:
- 가장 검증된 데이터베이스 — 20년 이상 운영 사례
- JSON 컬럼 지원 → 유연성도 어느 정도 확보
- Managed(직접 운영 안 하고 외부 서비스가 대신 관리) 호스팅 선택지 풍부

---

## 2. 호스팅 방식

| 옵션 | 무료 한도 | 유료 시작 | 특징 |
|---|---|---|---|
| **Supabase** | 500MB, 2개 프로젝트 | $25/월 | ✅ Postgres + Auth + Storage + Realtime 통합 |
| **Neon** | 0.5GB, 자동 sleep | $19/월 | ✅ 서버리스, 브랜치 가능 |
| Railway | $5 크레딧 | $5+ | 간단한 호스팅 |
| AWS RDS | 12개월 무료 | $15+ | 엔터프라이즈, 복잡 |
| Self-host | - | 서버 비용 | ❌ 운영 부담 |

**추천**:
- 빠른 개발 + 인증·스토리지 통합: **Supabase**
- 순수 DB만: **Neon**

**비개발자 설명**:
```
Supabase는 "DB + 회원관리 + 파일 저장"이 한 곳에 모인 서비스입니다.
회원가입 화면도 이 안에 있는 기능을 쓰면 1시간이면 됩니다.

Neon은 순수 DB만 제공합니다. 인증·스토리지는 별도 서비스 조합.

처음엔 Supabase 추천. 나중에 분리할 수 있습니다.
```

---

## 3. ORM (Object-Relational Mapping)

### 비개발자에게 설명

```
ORM은 "데이터베이스 표를 코드 객체처럼 다루게 해주는 도구"입니다.
원래는 SQL 쿼리를 직접 써야 하는데, ORM을 쓰면 코드만으로 데이터 조작 가능.
```

### 옵션 비교

| 옵션 | 비교 |
|---|---|
| **Prisma** | ✅ 표준. 타입 자동 생성, Migration 도구 우수 |
| Drizzle | 가벼움. SQL과 유사 |
| TypeORM | 트렌드 감소 |
| Kysely | SQL Builder. Prisma 대안 |

**추천**: Prisma (Node.js 기준)
**Python 사용 시**: SQLAlchemy

---

## 4. 캐시 / 검색 (필요한 경우)

### 캐시

| 옵션 | 추천 시점 |
|---|---|
| **불필요 (v1)** | ✅ 대부분 v1에서 캐시 없이 충분 |
| Redis (Upstash) | DAU 10,000+ 또는 API 호출 부하 |
| Vercel KV | Vercel 환경에서 간단히 |

**원칙**: 캐시는 성능 문제 발생 후 도입. 미리 도입하면 디버깅 복잡도만 늘어남.

### 검색

| 옵션 | 추천 시점 |
|---|---|
| **PostgreSQL Full-Text Search** | ✅ v1 표준 (Postgres 기본 기능) |
| Algolia | 검색이 핵심 기능일 때 |
| Meilisearch | 자체 호스팅 검색 |
| Elasticsearch | ❌ 운영 복잡, 시기상조 |

**추천 (v1)**: Postgres FTS 활용

---

## 표준 추천 스택 (요약)

```
PostgreSQL (Supabase Managed)
+ Prisma ORM
+ 캐시: 없음 (v1)
+ 검색: Postgres FTS
```

---

## 비용 추정

| 단계 | DB | 합계 |
|---|---|---|
| 개발 / 베타 | 무료 (Supabase Free) | 무료 |
| v1 (DAU 1,000) | $25/월 (Supabase Pro) | $25 |
| 성장 (DAU 10,000) | $25~$50/월 | $50 |

---

## 사용자에게 묻는 1차 질문

```
Q1. 데이터베이스는 위 표준 추천(PostgreSQL + Supabase)으로 가시겠습니까?
A. 표준 추천대로
B. Supabase 대신 Neon만 (인증은 NextAuth로)
C. 다른 DB (이유와 함께)

Q2. 캐시는?
A. 없이 시작 (권장, v1)
B. Upstash Redis 도입 (특별한 이유가 있을 때)

이유: 캐시는 성능 문제 발생 후 도입이 원칙. 미리 도입하면 디버깅만 복잡해집니다.
```

---

## 데이터 모델 (이 라운드의 별도 단계)

DB 결정 후 FRD 화면을 보고 테이블 도출:

```markdown
## 데이터 모델 초안

### users
- id: uuid (PK)
- email: string (unique)
- created_at: timestamp

### projects
- id: uuid (PK)
- user_id: uuid (FK → users.id)
- name: string
- created_at: timestamp

### project_results
- id: uuid (PK)
- project_id: uuid (FK → projects.id)
- content: jsonb
- created_at: timestamp
```

**모듈별 테이블 prefix 권장**: `auth_users`, `billing_invoices`, `core_projects` 등.
나중에 모듈 분리가 쉬워진다.
