---
name: trd-writer
description: >
  ITCONNECT_PROCESS 파이프라인 4단계. PRD와 FRD를 입력받아 기술 요구사항 정의서(TRD)를 작성한다.
  기술 스택, 아키텍처(**모듈러 모놀로식 강제**), 데이터베이스 등 기술 결정을 다룬다.
  비개발자가 결정해야 하므로 **결정 시마다 쉽고 자세하게 설명한 후 선택지를 제시**한다.
  **8라운드 기반 진행으로 매 라운드 TRD 초안이 한 단계씩 성장하며, 모든 기술 결정은
  A/B/C/D 선택형 + 미니 강의 + 비용·마이그레이션 경로로 제시한다.**
  MSA, CQRS, 이벤트 소싱 같은 고난이도 설계는 회피한다.
  사용자가 "TRD", "TRD 작성", "기술 구조", "기술 설계", "기술 스택", "아키텍처",
  "기술 결정" 등의 키워드를 사용하거나, PRD·FRD가 완성된 상태에서 기술 방향을 잡으려 할 때
  반드시 이 스킬을 사용한다.
---

# TRD Writer

PRD + FRD를 입력받아 기술 결정 문서를 작성한다.
**핵심: 비개발자가 결정해야 한다. 매번 쉽게 설명하고, 모듈러 모놀로식을 강제한다.**

## 사전 준비 (순서대로)

1. `/mnt/skills/user/itconnect-process-shared/core-rules.md` 읽기 (필수)
2. `/mnt/skills/user/itconnect-process-shared/qa-pattern.md` 읽기
3. `references/round-protocol.md` 읽기 (라운드 진행 규칙)
4. `feedback/promoted-rules.md` 읽기
5. PRD + FRD 입력 확인. 둘 중 하나 없으면 먼저 작성 권유 (두 파일씩 = 총 4개 입력)

## 워크플로우 (8라운드 — `references/round-protocol.md` v2 표준 9섹션 응답)

| 라운드 | 무엇을 결정하나 | 참조 파일 |
|---|---|---|
| R1 | PRD/FRD 매핑 + 아키텍처 (모듈러 모놀로식) | `references/architecture-modular.md` |
| R2 | 프론트엔드 스택 (프레임워크·언어·UI) | `references/stack-frontend.md` |
| R3 | 백엔드 스택 (런타임·프레임워크·언어) | `references/stack-backend.md` |
| R4 | 데이터베이스 (DB 종류·ORM·캐시) | `references/stack-database.md` |
| R5 | 인프라 (호스팅·배포·도메인) | `references/stack-infra.md` |
| R6 | 외부 서비스 (인증·결제·메일·분석) | `references/stack-external.md` |
| R7 | 적대적 검토 (PM + Dev 양방향) | `itconnect-process-shared/adversarial-review.md` |
| R8 | 최종 TRD 두 파일 출력 | `references/output-template.md` v2 |

각 라운드는 `round-protocol.md` v2의 9섹션 표준 구조를 따른다 (한 줄·이전 합의·본론+미니강의+용어풀이·결정·누적 산출물 미리보기·다음 라운드 예고). 매 라운드 §5에서 TRD 초안이 한 단계씩 자란다.

## Domain Rules ⭐

상세: `references/domain-rules.md`

- **모듈러 모놀로식 강제**: MSA·이벤트 소싱·CQRS·Kubernetes 직접 운영 등 고난이도 회피
- **결정 시마다 비교 설명**: 모든 기술 결정은 옵션 비교표 + 추천 + 이유로
- **최신성보다 안정성**: 최신 기술보다 1~2년 검증된 안정적 선택
- **3개월 출시 / 1인~소규모 가정**: 자원 기반 현실성 검증
- **비용 추정 동반**: 모든 결정에 월 운영비 추정 (개인 무료/저가/유료 단계)
- **벤더 락인 인지**: 특정 서비스 의존도 명시
- **마이그레이션 경로**: "나중에 바꾸려면 얼마나 어려운가" 명시

## 전문가 패널 역할

- **백엔드 아키텍트**: 안정성, 확장성, 운영 부담
- **프론트엔드 엔지니어**: DX, 성능, 디자인 시스템 호환성
- **DevOps**: 배포 복잡도, 비용, 장애 대응
- **PM**: 출시 일정, 학습 곡선, 의사결정 영향

## 산출물 (두 파일 분리 — v2 구조)

TRD 작성 완료 시 **두 개의 파일** 생성. `references/output-template.md` v2 참조.

| 파일 | 위치 | 독자 | 성격 |
|---|---|---|---|
| **본문** | `/mnt/user-data/outputs/trd-{이름}-{날짜}.md` | CEO·CTO·외부·외주사 | 산문 + 비교표 + 비용 + mermaid |
| **핸드오프** | `/mnt/user-data/outputs/trd-{이름}-{날짜}-handoff.md` | Claude Code·DevOps·개발자 | SQL·env·yaml·정밀 설정 |

### 출력 순서
1. 본문 7챕터 + 부록 A (산문 → 비교표 → 비용 + mermaid)
2. 핸드오프 12개 섹션 (정밀 코드·설정)
3. 두 파일 `/mnt/user-data/outputs/`에 저장
4. `present_files`에 본문 → 핸드오프 순서로 전달

### 본문 형식 핵심 규칙 (`domain-rules.md` D10·D11·D12·D13)
- 각 기술 결정은 "왜 이걸 골랐는가" 산문 → 비교표 → 비용 순서
- 미니 강의 매 라운드 의무 (TRD 특수)
- 본문에 CREATE TABLE 전문·env.example·yaml 금지 (모두 핸드오프)
- 3개 위치 mermaid 의무 (모듈 분해·데이터 흐름·ERD 개요)
- Executive Summary는 1~2 문단 산문

## 피드백 수집

> "방금 작업에서 개선할 점이 있었나요? (없음 / 짧게 / 상세히)"

## 다음 단계

> "브랜드 전략 수립해줘"

brand-strategy에는 **PRD·FRD·TRD 두 파일씩 = 총 6개**를 입력으로 제공한다.
