# trd-writer 변경 이력

## v2.0.0 (2026-05-17)

**대규모 재설계 — 모듈러 모놀로식 강제 + 비개발자 설명 의무 최강 적용**

### 사용자 요청 반영 (가장 중요)
- 사용자 정의 4번: "결정 시마다 쉽고 자세히 설명, MSA 같은 고난이도 회피, 모듈러 모놀로식"
- D1 도메인 규칙으로 모듈러 모놀로식 강제
- D2 비교 설명 의무
- D7 비개발자 친화 설명 의무 (가장 강하게 적용)

### 입력 자료 정정
- 사용자 정의 4번의 "PRD와 TRD" 오타 → PRD + FRD로 확정
- handoff-mapping.md에 명시

### 구조 변경
- SKILL.md 슬림화 (이전 334줄 → 약 60줄)
- 상세 내용을 `references/` 8개 파일로 분리
- `feedback/` 폴더 신설

### 신규 references/ 파일
- `architecture-modular.md` — 모듈러 모놀로식 강제 + 비교표 + 비개발자 설명 ⭐
- `stack-frontend.md` — 프론트엔드 결정 가이드
- `stack-backend.md` — 백엔드 결정 가이드
- `stack-database.md` — DB 결정 가이드
- `stack-infra.md` — 인프라 결정 가이드
- `stack-external.md` — 외부 서비스 결정 가이드
- `output-template.md` — 10개 섹션 + 비용 추정 + 마이그레이션 경로
- `domain-rules.md` — 9개 강제 규칙

### 핵심 신규/강화 규칙
- D1. 모듈러 모놀로식 강제 (MSA·CQRS·이벤트 소싱 거부)
- D2. 결정 시마다 비교표 + 추천 + 이유 + 비용
- D3. 최신성보다 안정성
- D6. 마이그레이션 경로 명시 (락인 평가)
- D7. 비개발자 친화 설명 의무 (가장 강하게)

### 핸드오프 정합성
- 입력: PRD (prd-writer) + FRD (frd-writer)
- 출력: brand-strategy의 입력

---

## 향후 버전 관리

- Major: 워크플로우 변경
- Minor: 새 기술 옵션 추가
- Patch: 가격 업데이트, Gotchas 추가
