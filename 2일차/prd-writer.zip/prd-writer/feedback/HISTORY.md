# prd-writer 변경 이력

## v2.0.0 (2026-05-17)

**대규모 재설계 — Progressive Disclosure 적용**

### 구조 변경
- SKILL.md 슬림화 (이전 258줄 → 약 60줄)
- 상세 내용을 `references/` 폴더 6개 파일로 분리
- `feedback/` 폴더 신설 (자체 루프 시스템)
- itconnect-process-shared v2 슬림화에 맞춰 경로 갱신

### 신규 references/ 파일
- `handoff-mapping.md` — 정의서→PRD 매핑표 (재질문 금지)
- `persona-flow.md` — 페르소나 + 사용자 흐름
- `feature-breakdown.md` — 기능 분해 + 우선순위 분류
- `round-protocol.md` — 8라운드 진행 규칙
- `output-template.md` — 17개 섹션 표준 + 바이브코딩 호환 체크
- `domain-rules.md` — 스킬 전용 8개 규칙

### 신규 feedback/ 파일
- `HISTORY.md` (본 파일)
- `lessons-learned.md`, `pending-feedback.md`, `promoted-rules.md`

### 주요 신규/강화 규칙
- D1. 정의서 재질문 금지 (시간 낭비 차단)
- D7. 바이브코딩 호환 형식 의무 (Claude Code/Cursor 입력 가능)
- 한 라운드 한 섹션 원칙 명문화 (D5)

### 핸드오프 정합성
- 입력: service-ideation의 서비스 정의서
- 출력: frd-writer의 입력 (handoff-format.md 표준)

---

## 향후 버전 관리

- Major: 워크플로우 변경
- Minor: 라운드 추가, references 파일 추가
- Patch: Gotchas 추가, 예시 보강
