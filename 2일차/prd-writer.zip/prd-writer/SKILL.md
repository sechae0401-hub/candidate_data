---
name: prd-writer
description: >
  ITCONNECT_PROCESS 파이프라인 2단계. 서비스 정의서를 입력받아 AI 바이브코딩 입력으로 바로 사용 가능한
  PRD(제품 요구사항 정의서)를 질의응답으로 작성한다. 기능별 "왜 필요한지·누구를 위한 것인지·
  1차에 정말 필요한지"를 먼저 따진다. **비개발자가 매 라운드 결정을 자연스럽게 이해하며 진행할 수 있도록,
  어려운 용어는 본문 흐름 안에서 일상 비유로 풀이하고, 모든 결정은 A/B/C/D 선택형 + 미니 강의로
  제시한다. 매 라운드 PRD 초안이 한 단계씩 성장하는 점진적 고도화 흐름을 유지한다.**
  사용자가 "PRD", "PRD 작성", "제품 요구사항", "기능 정의",
  "서비스 기획서", "요구사항 정의" 등의 키워드를 사용하거나, 서비스 정의서가 있는 상태에서
  구체적인 기능 목록과 화면 구조를 정리하려 할 때 반드시 이 스킬을 사용한다.
  서비스 정의서가 없으면 service-ideation을 먼저 호출한다.
---

# PRD Writer

서비스 정의서를 PRD로 확장한다. 이 PRD는 다음 단계 frd-writer의 입력이 되고,
나아가 AI 바이브코딩 도구(Claude Code, Cursor 등)의 직접 입력으로 사용된다.

## 사전 준비 (순서대로)

1. `/mnt/skills/user/itconnect-process-shared/core-rules.md` 읽기 (필수)
2. `/mnt/skills/user/itconnect-process-shared/qa-pattern.md` 읽기 (질의응답형)
3. `feedback/promoted-rules.md` 읽기 (있으면 적용)
4. 입력으로 서비스 정의서가 제공되었는지 확인. 없으면 service-ideation 먼저 호출 권유

## 워크플로우

| 단계 | 무엇을 한다 | 참조 파일 |
|---|---|---|
| 1 | 서비스 정의서 매핑 (재질문 금지) | `references/handoff-mapping.md` |
| 2 | 페르소나 구체화 + 사용자 흐름 합의 | `references/persona-flow.md` |
| 3 | 기능 분해 + 필수/선택/후순위 분류 | `references/feature-breakdown.md` |
| 4 | 라운드별 합의 (1라운드 = 1섹션) | `references/round-protocol.md` |
| 5 | 적대적 검토 (Architect + Dev 관점) | `itconnect-process-shared/adversarial-review.md` |
| 6 | 최종 PRD + 핸드오프 | `references/output-template.md` |
| 7 | 피드백 회수 → `feedback/pending-feedback.md` | - |

## Domain Rules

상세: `references/domain-rules.md` 참조

- 서비스 정의서에 있는 항목은 **재질문 금지** (그대로 매핑 후 확인만)
- 모든 기능은 **필수 / 선택 / 후순위** 분류 의무
- "향후 확장" 항목을 MVP에 끼워넣는 시도 차단
- 기능 설명에 **사용자 흐름 + 예외 상황** 동반 의무
- 한 라운드 한 섹션 원칙 (한 번에 PRD 전체를 쓰지 않음)
- 바이브코딩 입력 가능 형식 유지 (AI가 읽기 쉬운 구조)

## 전문가 패널 역할 (패널 모드 시)

- **서비스 기획자**: 사용자 가치, 사용 흐름, 정보 구조
- **프로덕트 오너**: MVP 범위, 우선순위, 비즈니스 임팩트
- **UX 설계자**: 예외 상태, 인터페이스 복잡도
- **운영/CS**: 관리자 기능 누락, 운영 부하, 정책 모호성

## 산출물 (두 파일 분리 — v2 구조)

PRD 작성 완료 시 **두 개의 파일**을 생성한다. `references/output-template.md` v2 참조.

| 파일 | 위치 | 독자 | 성격 |
|---|---|---|---|
| **본문** | `/mnt/user-data/outputs/prd-{서비스명}-{YYYYMMDD}.md` | 대표·동료·외부 이해관계자 | 처음부터 끝까지 읽는 보고서 (산문·표·mermaid) |
| **핸드오프** | `/mnt/user-data/outputs/prd-{서비스명}-{YYYYMMDD}-handoff.md` | frd-writer / Claude Code | 정밀 데이터 카탈로그 (ID 표·SQL·프롬프트) |

### 출력 순서
1. 본문 파일 먼저 작성 → 7개 챕터 + 부록 A (`output-template.md` Part A)
2. 핸드오프 파일 작성 → 11개 섹션 (`output-template.md` Part B)
3. 두 파일 모두 `/mnt/user-data/outputs/`에 저장
4. `present_files`에 본문 → 핸드오프 순서로 전달

### 본문 형식 핵심 규칙 (`domain-rules.md` D9·D10·D11)
- 산문 도입 → 표/리스트/코드 순서 의무
- 본문에 F-001·S-001 같은 ID 표 금지 (핸드오프로 분리)
- 4개 위치 mermaid 다이어그램 의무 (시나리오·화면 구조·데이터 모델·API 호출)
- Executive Summary는 1~2 문단 산문 (8항목 나열 금지)

## 피드백 수집

산출물 완료 시:
> "방금 작업에서 개선할 점이 있었나요? (없음 / 짧게 / 상세히)"

응답이 있으면 `feedback/pending-feedback.md`에 원문 기록.

## 다음 단계

> "FRD 작성해줘"

frd-writer에는 **두 파일 모두**를 입력으로 제공한다.
- `prd-{서비스명}-{YYYYMMDD}.md` (본문)
- `prd-{서비스명}-{YYYYMMDD}-handoff.md` (핸드오프, 정밀 데이터)
