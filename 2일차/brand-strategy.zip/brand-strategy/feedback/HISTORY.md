# brand-strategy 변경 이력

## v2.0.0 (2026-05-17)

**대규모 재설계 — Progressive Disclosure 적용 + 이미지 프롬프트 분리**

### 구조 변경
- SKILL.md 슬림화 (이전 182줄 → 약 60줄)
- 상세 내용을 `references/` 6개 파일로 분리
- `feedback/` 폴더 신설

### 신규 references/ 파일
- `brand-essence.md` — Why/How/What 본질 도출 (R1)
- `positioning.md` — 경쟁/대체재 3개 이상 의무 (R2)
- `tone-persona.md` — 페르소나 + 톤 매트릭스 + 단어 가이드 (R3)
- `naming.md` — 네이밍 + 슬로건 + 도메인/SNS 확인 (R4)
- `visual-direction.md` — 시각 방향 + 금지 인상 5개 이상 (R5)
- `output-template.md` — 7개 섹션 + 마이크로카피 예시
- `domain-rules.md` — 8개 강제 규칙

### 신규 feedback/ 파일
- HISTORY, lessons-learned, pending-feedback, promoted-rules

### 핵심 신규/강화 규칙
- D1. 이미지 프롬프트 분리 (logo-prompt-builder / og-image-prompt-builder가 담당)
- D2. 추상 형용사 금지
- D3. 경쟁 분석 3개 이상 의무
- D4. 금지 인상 5개 이상 의무
- D5. 시각은 후순위 (본질부터)

### 핸드오프 정합성
- 입력: PRD + FRD + TRD
- 출력: design-system-builder의 입력

---

## 향후 버전 관리

- Major: 워크플로우 변경
- Minor: 새 라운드 추가
- Patch: 단어 가이드 보강, 예시 추가
