---
name: brand-strategy
description: >
  ITCONNECT_PROCESS 파이프라인 5단계. PRD/FRD/TRD가 완성된 후 서비스의 브랜드 전략을 수립한다.
  브랜드 전략 수립에 필요한 정보를 먼저 요청하고, 충분한 질문과 가이드를 통해 사용자가
  브랜드 정체성·포지셔닝·톤앤매너·네이밍·시각 언어 방향을 결정할 수 있도록 돕는다.
  사용자가 "브랜딩", "브랜드 전략", "브랜딩 수립", "네이밍", "톤앤매너", "브랜드 아이덴티티",
  "포지셔닝" 등의 키워드를 사용하거나, 제품 문서가 완성된 후 브랜드 방향을 잡으려 할 때
  반드시 이 스킬을 사용한다.
---

# Brand Strategy

서비스의 브랜드 전략을 수립한다. 디자인 시스템 빌더의 입력이 되며,
이후 모든 마케팅 자산(SNS, 블로그, 페이지)의 톤을 결정한다.

## 사전 준비 (순서대로)

1. `/mnt/skills/user/itconnect-process-shared/core-rules.md` 읽기 (필수)
2. `/mnt/skills/user/itconnect-process-shared/qa-pattern.md` 읽기
3. `feedback/promoted-rules.md` 읽기
4. PRD/FRD/TRD 입력 확인 (없어도 진행 가능, 단 결과 품질 저하 명시)

## 워크플로우 (5라운드)

| 라운드 | 무엇을 결정하나 | 참조 파일 |
|---|---|---|
| R1 | 정보 수집 + 브랜드 본질 | `references/brand-essence.md` |
| R2 | 포지셔닝 (경쟁/대체재 대비) | `references/positioning.md` |
| R3 | 톤앤매너 + 페르소나 | `references/tone-persona.md` |
| R4 | 네이밍 + 슬로건 | `references/naming.md` |
| R5 | 시각 언어 방향 (색·폰트·인상) | `references/visual-direction.md` |
| 최종 | 적대적 검토 + 출력 | `references/output-template.md` |

## Domain Rules

상세: `references/domain-rules.md`

- **이미지 프롬프트는 분리**: 로고는 logo-prompt-builder, OG는 og-image-prompt-builder가 담당. 본 스킬은 방향만 결정
- **추상 형용사 금지**: "혁신적", "최적의" → 구체 표현으로
- **3개 이상 경쟁 분석 의무**: 1~2개는 차별점 도출 부족
- **금지 인상 정의 의무**: "이렇게 보이면 실패"를 명시
- **시각 결정은 후순위**: 색·폰트 전에 본질·포지셔닝 먼저

## 전문가 패널 역할

- **브랜드 전략가**: 본질, 포지셔닝, 일관성
- **카피라이터**: 메시지, 톤, 슬로건
- **크리에이티브 디렉터**: 시각 방향, 인상, 차별점
- **시장 분석가**: 경쟁, 대체재, 타겟 인식

## 산출물

- 위치: `/mnt/user-data/outputs/brand-strategy-{서비스명}-{YYYYMMDD}.md`
- 형식: `references/output-template.md`
- 핸드오프 필수

## 피드백 수집

> "방금 작업에서 개선할 점이 있었나요? (없음 / 짧게 / 상세히)"

## 다음 단계

> "디자인 시스템 만들어줘"
