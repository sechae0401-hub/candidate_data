---
name: service-ideation
description: >
  비개발자가 가진 막연한 서비스 아이디어를 사업 가능한 개념으로 구체화하는 ITCONNECT_PROCESS
  파이프라인 1단계 스킬. 질의응답으로 고객·문제·솔루션·MVP를 정의하고 "서비스 정의서"와
  "PRD 입력용 요약본"을 생성한다. **어려운 용어는 본문 흐름 안에서 일상 비유로 풀이하고,
  모든 결정은 A/B/C/D 선택형 + 미니 강의로 제시하여 매 응답마다 산출물이 한 단계씩
  자라나는 자연스러운 고도화 흐름을 유지한다.** 사용자가 "서비스 아이디어", "아이디어 구체화",
  "사업 아이디어 정리", "새로운 서비스", "아이디어 검증", "서비스 컨셉 정리" 등의 키워드를
  사용하거나 PRD가 없는 상태에서 서비스 방향을 잡으려 할 때 반드시 이 스킬을 사용한다.
  구체적인 기능 목록·화면 구조 작성 요청은 prd-writer를 사용한다.
---

# Service Ideation

비개발자의 막연한 아이디어를 PRD 작성 가능한 수준으로 구체화한다.
파이프라인 1단계이므로 여기서 부실하면 PRD/FRD/TRD 전부 흔들린다.

## 사전 준비 (순서대로)

1. `/mnt/skills/user/itconnect-process-shared/core-rules.md` 읽기 (필수)
2. `/mnt/skills/user/itconnect-process-shared/qa-pattern.md` 읽기 (질의응답형이므로 필수)
3. `feedback/promoted-rules.md` 읽기 (누적된 교훈이 있으면 적용)

## 워크플로우

| 단계 | 무엇을 한다 | 참조 파일 |
|---|---|---|
| 1 | 입력 진단 + v0.1 초안 | `references/diagnosis-template.md` |
| 2 | 1차 질문 일괄 발사 (선택형) | `references/question-bank.md` |
| 3 | 답변 반영, 매 응답 풀 사이클 | `qa-pattern.md` Step 3 |
| 4 | 품질 체크리스트 통과 시 산출물 작성 | `references/quality-checklist.md` |
| 5 | 적대적 검토 (PM 관점) | `itconnect-process-shared/adversarial-review.md` |
| 6 | Self-Check 후 최종 산출물 + 핸드오프 | `references/output-template.md`, `itconnect-process-shared/handoff-format.md` |
| 7 | 사용자에게 피드백 회수 | `feedback/pending-feedback.md`에 기록 |

## Domain Rules (이 스킬만의 강제 규칙)

상세: `references/domain-rules.md` 참조

- 솔루션보다 먼저 **고객·문제·대체재**를 파악
- 타겟을 **"모든 사람"** 으로 설정 금지 → 한 문장으로 특정 가능해야 함
- 시장 검증 없이 솔루션 구체화 금지
- "좋은 아이디어네요" 같은 빈 칭찬 금지
- MVP는 **3개월·소규모 팀**으로 구현 가능한 범위로 압축

## 산출물

- 위치: `/mnt/user-data/outputs/service-definition-{서비스명}-{YYYYMMDD}.md`
- 형식: `references/output-template.md` 그대로 사용
- 마지막에 **다음 단계 입력 요약본** 부착 (handoff-format.md 표준)

## 피드백 수집

산출물 완료 시 사용자에게 묻기:
> "방금 작업에서 개선할 점이 있었나요? (없음 / 짧게 / 상세히)"

응답이 있으면 `feedback/pending-feedback.md`에 timestamp + 원문 그대로 기록.
임의 해석·요약 금지.

## 다음 단계

산출물 완성 후:
> "PRD 작성해줘"
