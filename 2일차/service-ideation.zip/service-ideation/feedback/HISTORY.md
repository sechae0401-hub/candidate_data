# service-ideation 변경 이력

## v2.0.0 (2026-05-17)

**대규모 재설계 — Progressive Disclosure 적용**

### 구조 변경
- SKILL.md를 60줄 이하로 슬림화 (이전: 약 230줄)
- 상세 내용을 `references/` 폴더로 분리
- `feedback/` 폴더 신설 — 자체 루프 고도화 시스템 구축
- `itconnect-process-shared` 슬림화에 맞춰 참조 경로 갱신

### 신규 references/ 파일
- `diagnosis-template.md` — Step 1 진단 형식
- `question-bank.md` — 1차/2차 질문 풀
- `quality-checklist.md` — 7개 PASS/FAIL 게이트
- `output-template.md` — 최종 산출물 표준
- `domain-rules.md` — 스킬 전용 강제 규칙 (비개발자 친화 의무 포함)
- `examples.md` — 좋은/나쁜 사례

### 신규 feedback/ 파일
- `HISTORY.md` (본 파일)
- `lessons-learned.md` — 누적 교훈
- `pending-feedback.md` — 사용자 피드백 대기열
- `promoted-rules.md` — 정식 승격 규칙 (SKILL.md가 자동 로드)

### 주요 신규 규칙
- D1. 솔루션 후순위 원칙 (고객·문제·대안 먼저)
- D2. "모든 사람" 타겟 금지
- D5. MVP 3개월 / 소규모 원칙 강화
- D6. 비개발자 친화 설명 의무 (용어 풀이·일상 비유)

### 호환성
- 이전 SKILL.md 내용은 기능적으로 모두 보존됨 (위치만 이동)
- itconnect-process-shared 슬림화 버전과 함께 사용

---

## v1.x.x (이전)

- 단일 SKILL.md 파일로 운영
- itconnect-process-shared의 common-operating-block.md를 매 호출 시 12K 통째로 로드

---

## 향후 버전 관리 원칙

- Major (X.0.0): 구조 변경, 워크플로우 변경
- Minor (1.X.0): 새 references 파일 추가, 질문 풀 확장
- Patch (1.0.X): Gotchas 추가, 예시 보강, 오타 수정

피드백 누적으로 `promoted-rules.md`에 신규 규칙이 추가될 때마다 Patch 버전 증가.
