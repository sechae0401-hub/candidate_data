---
name: project-qa
description: >
  ITCONNECT_PROCESS 파이프라인 8단계 (최종). 서비스 정의서·PRD·FRD·TRD·브랜드 전략·디자인 시스템·
  페이지 기획안(옵션)·프론트엔드 구현물을 한꺼번에 크로스체크하는 통합 검수 스킬.
  문제를 지적만 하지 않고 **수정안과 재지시 프롬프트까지 함께 제시**한다.
  사용자가 "최종 검수", "통합 검수", "전체 리뷰", "QA", "크로스체크",
  "문서 간 충돌 확인", "출시 전 점검" 등의 키워드를 사용하거나, 모든 문서가 준비된 상태에서
  최종 정합성을 확인하려 할 때 반드시 이 스킬을 사용한다.
---

# Project QA (최종 통합 검수)

ITCONNECT_PROCESS 7개 산출물(+옵션 페이지)을 한꺼번에 검수해 출시 전 충돌·누락·일관성 문제를 잡는다.
**이 스킬은 실행형이다. 질의응답이 아닌 즉시 검수 실행.**

## 사전 준비 (순서대로)

1. `/mnt/skills/user/itconnect-process-shared/core-rules.md` 읽기 (필수)
2. `feedback/promoted-rules.md` 읽기 (있으면 적용)
3. 입력 문서 목록 확인 — 없는 문서는 명시

(질의응답형 아님. qa-pattern.md 로드 불필요)

## 워크플로우 (5단계, 실행형)

| 단계 | 무엇을 한다 | 참조 파일 |
|---|---|---|
| 1 | 입력 문서 수집 확인 + 빠진 문서 명시 | `references/input-checklist.md` |
| 2 | 문서 간 충돌 탐지 (8개 매트릭스) | `references/conflict-detection.md` |
| 3 | 15개 범주 체크리스트 실행 | `references/checklist-matrix.md` |
| 4 | 이슈별 수정안 + 재지시 프롬프트 작성 | `references/fix-protocol.md` |
| 5 | 종합 판정 (PASS / CONDITIONAL / FAIL) + 출력 | `references/output-template.md` |

## Domain Rules

상세: `references/domain-rules.md`

- **"사소한 차이"로 넘기지 않음**: 충돌은 무조건 짚는다
- **문제 지적 + 수정안 + 재지시 프롬프트 3종 의무** (audit + rewrite)
- **모든 이슈에 심각도 부여**: Critical / High / Medium / Low
- **종합 판정 의무**: PASS / CONDITIONAL PASS / FAIL
- **수정 후 재확인 체크리스트 동반**
- **필수 문서 누락 시 검수 거부** (PRD/FRD/TRD는 필수)

## 전문가 패널 역할

- **프로덕트 매니저**: 서비스 정의 ↔ 기능 ↔ UX 흐름 정합성
- **브랜드 디렉터**: 브랜딩 ↔ 카피 ↔ 시각 언어 일관성
- **기술 리드**: PRD ↔ FRD ↔ TRD 기술 정합성
- **QA 리드**: 예외 상태, 에러 처리, 테스트 커버리지

## 산출물

- 위치: `/mnt/user-data/outputs/qa-report-{서비스명}-{YYYYMMDD}.md`
- 형식: `references/output-template.md`
- 핸드오프: 다음 단계가 없으므로 핸드오프 대신 **출시 전 액션 아이템 리스트** 부착

## 피드백 수집

> "방금 작업에서 개선할 점이 있었나요? (없음 / 짧게 / 상세히)"

## 검수 후 흐름

1. PASS → 출시 진행
2. CONDITIONAL PASS → Critical/High 항목 수정 후 재검수 요청
3. FAIL → 해당 단계부터 재작업 (어느 단계인지 명시)
