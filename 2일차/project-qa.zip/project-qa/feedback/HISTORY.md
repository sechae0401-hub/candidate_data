# project-qa 변경 이력

## v2.0.0 (2026-05-17)

**대규모 재설계 — Progressive Disclosure 적용**

### 구조 변경
- SKILL.md 슬림화 (이전 169줄 → 약 55줄)
- 상세 내용을 `references/` 5개 파일로 분리
- `feedback/` 폴더 신설
- 죽은 링크 "design-review" 스킬 참조 제거

### 신규 references/ 파일
- `input-checklist.md` — 입력 문서 분류 + 누락 처리 + 호환 형식
- `conflict-detection.md` — 8개 비교 매트릭스 ⭐
- `checklist-matrix.md` — 15개 범주 PASS/FAIL 체크
- `fix-protocol.md` — 이슈 5영역 + 심각도 + 재지시 프롬프트 ⭐
- `output-template.md` — 11개 섹션 + 종합 판정
- `domain-rules.md` — 10개 강제 규칙

### 핵심 신규/강화 규칙
- D2. 문제 + 수정안 + 재지시 프롬프트 3종 의무 (audit + rewrite)
- D4. 종합 판정 의무 (PASS / CONDITIONAL / FAIL)
- D5. 수정 후 재확인 체크리스트 동반
- D6. 필수 문서 누락 시 검수 거부
- D7. 스킵 항목 명시 의무
- D8. 오탐 경고 의무 (AI 발견의 한계 명시)

### 핸드오프 정합성
- 입력: PRD + FRD + TRD (필수) / 브랜드 + 디자인 + 페이지 + 구현물 (권장)
- 출력: 출시 전 액션 아이템 (다음 스킬 없음, 파이프라인 마지막)

---

## 향후 버전 관리

- Major: 새 비교 매트릭스 추가, 워크플로우 변경
- Minor: 체크리스트 범주 추가
- Patch: 이슈 사례 보강, 오탐 패턴 학습
