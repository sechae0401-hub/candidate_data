# frd-writer 변경 이력

## v2.0.0 (2026-05-17)

**대규모 재설계 — Progressive Disclosure + 핵심/부가 분리 강제**

### 사용자 요청 반영 (가장 중요)
- 사용자 정의 3번: "MVP 핵심 1~2개 + 부가 기능 명확히 분리"
- `references/core-vs-extra.md` 신설 — 이 스킬의 핵심 가치
- D1 도메인 규칙으로 강제

### 구조 변경
- SKILL.md 슬림화 (이전 246줄 → 약 60줄)
- 상세 내용을 `references/` 6개 파일로 분리
- `feedback/` 폴더 신설

### 신규 references/ 파일
- `handoff-mapping.md` — PRD→FRD 매핑
- `core-vs-extra.md` — 핵심 1~2 + Tier 1/2/3 분류 ⭐
- `blindspot-check.md` — 비개발자 누락 5종
- `screen-spec-template.md` — 화면별 5상태 + AC
- `output-template.md` — 11개 섹션 표준
- `domain-rules.md` — 8개 강제 규칙

### 신규 feedback/ 파일
- HISTORY, lessons-learned, pending-feedback, promoted-rules

### 핵심 신규 규칙
- D1. 핵심 1~2개 강제 (사용자 요청 반영)
- D2. 5개 상태 의무 (Empty/Loading/Error/Success/Disabled)
- D3. 측정 가능한 AC 의무
- 비개발자가 빠뜨리는 5종 자동 점검

### 핸드오프 정합성
- 입력: prd-writer의 PRD
- 출력: trd-writer의 입력

---

## 향후 버전 관리

- Major: 워크플로우 변경
- Minor: 새 점검 항목 추가
- Patch: Gotchas 추가, 예시 보강
