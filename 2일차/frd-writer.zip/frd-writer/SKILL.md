---
name: frd-writer
description: >
  ITCONNECT_PROCESS 파이프라인 3단계. PRD를 입력받아 실제 개발·디자인·테스트에 바로 사용 가능한
  상세 기능정의서(FRD)를 작성한다. 비개발자가 미처 생각하지 못한 부분(화면 상태, 예외, 권한, 검증)을
  반드시 짚어준다. **MVP 핵심 1~2개 + 부가 기능을 명확히 분리**하여 욕심으로 인한 범위 폭발을 차단한다.
  **라운드 기반 진행으로 한 라운드에 화면 1~2개씩만 다루며, 어려운 용어는 본문 흐름 안에서 일상
  비유로 풀이하고, 모든 결정은 A/B/C/D 선택형 + 미니 강의로 제시한다. 매 라운드 FRD 초안이
  한 단계씩 성장하는 점진적 고도화 흐름을 유지한다.**
  사용자가 "FRD", "기능정의서", "상세 기능 정의", "기능 명세", "기능 설계", "화면별 기능"
  등의 키워드를 사용하거나, PRD가 완성된 상태에서 개발 착수 전 상세 기능을 정의하려 할 때
  반드시 이 스킬을 사용한다.
---

# FRD Writer

PRD를 입력받아 화면별 상세 기능 명세를 작성한다.
**핵심: 비개발자가 빠뜨리는 것을 잡아내고, MVP 범위를 핵심 1~2개로 압축한다.**

## 사전 준비 (순서대로)

1. `/mnt/skills/user/itconnect-process-shared/core-rules.md` 읽기 (필수)
2. `/mnt/skills/user/itconnect-process-shared/qa-pattern.md` 읽기
3. `references/round-protocol.md` 읽기 (라운드 진행 규칙)
4. `feedback/promoted-rules.md` 읽기
5. PRD 입력 확인. 없으면 prd-writer 먼저 호출 권유

## 워크플로우 (라운드 기반)

| 라운드 | 무엇을 한다 | 참조 파일 |
|---|---|---|
| R1 | PRD 매핑 + 화면 목록 확정 | `references/handoff-mapping.md`, `references/round-protocol.md` |
| **R2** | **핵심 1~2개 vs 부가 분리** (FRD의 핵심) | `references/core-vs-extra.md` |
| R3~Rn | 화면별 상세 (한 라운드당 1~2개 화면) | `references/screen-spec-template.md` |
| R말-1 | Blindspot Check 5종 (상태/예외/권한/검증/엣지) | `references/blindspot-check.md` |
| R말 | 적대적 검토 (Dev + QA 관점) + 최종 FRD + 핸드오프 | `itconnect-process-shared/adversarial-review.md`, `references/output-template.md` |

각 라운드는 `qa-pattern.md` Step 3 풀 사이클(확정/추정/문제/추천/v0.X 초안/다음 질문) 강제. 매 라운드 §5에서 FRD 초안이 한 단계씩 자란다.

## Domain Rules

상세: `references/domain-rules.md`

- **MVP는 핵심 기능 1~2개 + 부가 기능으로 분리** (사용자 요청 핵심)
- 비개발자가 빠뜨리는 5가지를 매번 점검 (상태/예외/권한/검증/엣지)
- 화면 명세는 5개 상태 의무 정의 (Empty/Loading/Error/Success/Disabled)
- 측정 가능한 인수 기준(AC) 동반 의무
- 외부 의존성(API·서드파티)은 별도 섹션
- "추후 결정" 5개 초과 시 경고

## 전문가 패널 역할

- **개발자**: 구현 가능성, 기술 제약, 엣지 케이스
- **QA**: 테스트 가능성, 누락된 상태, 검증 기준
- **디자이너**: 화면 상태, 인터랙션, 일관성
- **운영자**: 관리자 시점, 데이터 흐름, 정책 충돌

## 산출물 (두 파일 분리 — v2 구조)

FRD 작성 완료 시 **두 개의 파일** 생성. `references/output-template.md` v2 참조.

| 파일 | 위치 | 독자 | 성격 |
|---|---|---|---|
| **본문** | `/mnt/user-data/outputs/frd-{이름}-{날짜}.md` | 디자이너·기획자·외부 | 화면별 산문 명세 + mermaid |
| **핸드오프** | `/mnt/user-data/outputs/frd-{이름}-{날짜}-handoff.md` | trd-writer·Claude Code·QA | 요소 ID·검증·AC 정밀 표 |

### 출력 순서
1. 본문 9개 챕터 + 부록 A (산문 → 표 → mermaid 순서)
2. 핸드오프 12개 섹션 (정밀 데이터)
3. 두 파일 `/mnt/user-data/outputs/`에 저장
4. `present_files`에 본문 → 핸드오프 순서로 전달

### 본문 형식 핵심 규칙 (`domain-rules.md` D9·D10·D11·D12)
- 화면 명세는 "이 화면은 무엇 → 어떻게 보이나 → 어떻게 동작하나" 산문 순서
- 본문에 요소 ID·정규식·AC 체크리스트 금지 (모두 핸드오프)
- 4개 위치 mermaid 의무 (화면 흐름·시나리오·5개 상태·외부 의존성)
- Executive Summary는 1~2 문단 산문

## 피드백 수집

> "방금 작업에서 개선할 점이 있었나요? (없음 / 짧게 / 상세히)"

## 다음 단계

> "TRD 작성해줘"

trd-writer에는 **PRD 두 파일 + FRD 두 파일 = 총 4개**를 입력으로 제공한다.
- `prd-{이름}-{날짜}.md` (본문)
- `prd-{이름}-{날짜}-handoff.md` (PRD 핸드오프)
- `frd-{이름}-{날짜}.md` (본문)
- `frd-{이름}-{날짜}-handoff.md` (FRD 핸드오프)
