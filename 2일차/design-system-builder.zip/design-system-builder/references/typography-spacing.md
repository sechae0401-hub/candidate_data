# Typography + Spacing + Shape Tokens

> 타이포·간격·형태(반경·그림자) 토큰 시스템.

---

## A. Typography Tokens

### 폰트 패밀리

브랜드 전략의 폰트 방향에서 구체화:

```css
--font-sans:       'Pretendard Variable', -apple-system, sans-serif;
--font-display:    'Geist', 'Pretendard Variable', sans-serif;  /* 제목용 */
--font-mono:       'JetBrains Mono', 'D2 Coding', monospace;     /* 코드/숫자 */
--font-serif:      'Source Serif Pro', serif;                    /* 인용·강조 (선택) */
```

**v1 표준**: sans + display 2종 (또는 1종으로 통일). 4종 이상은 운영 부담.

### 크기 스케일

```css
--text-xs:   12px;
--text-sm:   14px;
--text-base: 16px;  /* 본문 기준 */
--text-lg:   18px;
--text-xl:   20px;
--text-2xl:  24px;
--text-3xl:  30px;
--text-4xl:  36px;
--text-5xl:  48px;
--text-6xl:  60px;
--text-7xl:  72px;  /* 랜딩 히어로 */
```

### 라인 높이 (line-height)

```css
--leading-tight:    1.2;   /* 큰 제목 */
--leading-snug:     1.375; /* 중간 제목 */
--leading-normal:   1.5;   /* 본문 */
--leading-relaxed:  1.625; /* 한글 본문 (한글은 영문보다 1.5~1.7 권장) */
--leading-loose:    2;     /* 매우 여유 */
```

**한글 본문**: `1.625` 권장. 영문보다 더 여유로움이 필요.

### 자간 (letter-spacing)

```css
--tracking-tighter: -0.05em; /* 큰 제목, 임팩트 */
--tracking-tight:   -0.025em; /* 중간 제목 */
--tracking-normal:   0;       /* 본문 */
--tracking-wide:     0.025em; /* 캡션, 라벨 (대문자) */
--tracking-wider:    0.05em;
```

**한글 본문**: `0` 또는 약간의 음수 (-0.01em). 영문은 같은 폰트라도 다른 값.

### 굵기 (font-weight)

```css
--font-thin:       100;
--font-light:      300;
--font-normal:     400;
--font-medium:     500;
--font-semibold:   600;
--font-bold:       700;
--font-extrabold:  800;
--font-black:      900;
```

브랜드 페르소나에 따라 본문 굵기 결정:
- "단단함·신뢰" → 본문 `500`
- "압축적·미니멀" → 본문 `400`
- "따뜻함·친근" → 본문 `400` + 둥근 모양

### 텍스트 스타일 (조합)

자주 쓰는 조합을 변수로:

```css
/* Headings */
--text-hero:    900 60px/1.1 -0.04em var(--font-display);     /* 랜딩 H1 */
--text-h1:      800 36px/1.2 -0.03em var(--font-display);
--text-h2:      700 30px/1.3 -0.02em var(--font-display);
--text-h3:      600 24px/1.35 -0.01em var(--font-sans);
--text-h4:      600 20px/1.4 0 var(--font-sans);

/* Body */
--text-body:    400 16px/1.625 0 var(--font-sans);            /* 한글 본문 */
--text-body-sm: 400 14px/1.5 0 var(--font-sans);
--text-caption: 500 12px/1.5 0.025em var(--font-sans);
```

---

## B. Spacing Tokens (8 베이스 그리드)

### 베이스 단위

```css
--space-0:    0;
--space-1:    4px;
--space-2:    8px;
--space-3:    12px;
--space-4:    16px;
--space-5:    20px;
--space-6:    24px;
--space-8:    32px;
--space-10:   40px;
--space-12:   48px;
--space-16:   64px;
--space-20:   80px;
--space-24:   96px;
--space-32:   128px;
--space-40:   160px;
--space-48:   192px;
--space-64:   256px;
```

**원칙**: 모든 간격(padding, margin, gap)은 위 토큰 사용.
임의값 (`p-[13px]` 등) 사용 금지.

### 의미 단위 (선택)

```css
--space-component:  var(--space-4);  /* 컴포넌트 내부 */
--space-section:    var(--space-16); /* 섹션 간 */
--space-page:       var(--space-24); /* 페이지 좌우 패딩 */
```

---

## C. Shape Tokens (반경 + 그림자)

### Border Radius

```css
--radius-none:   0;
--radius-sm:     4px;
--radius:        6px;
--radius-md:     8px;
--radius-lg:     12px;
--radius-xl:     16px;
--radius-2xl:    24px;
--radius-full:   9999px; /* pill, 아바타 */
```

브랜드 인상에 따라 기본 반경 결정:
- "단단함·전문성" → `4~6px`
- "친근함·따뜻함" → `8~12px`
- "캐주얼·재미" → `12~16px+`
- "각진 모더니즘" → `0~2px`

### Shadow

```css
--shadow-sm:  0 1px 2px rgba(0,0,0,0.05);
--shadow:     0 1px 3px rgba(0,0,0,0.1), 0 1px 2px rgba(0,0,0,0.06);
--shadow-md:  0 4px 6px rgba(0,0,0,0.07), 0 2px 4px rgba(0,0,0,0.06);
--shadow-lg:  0 10px 15px rgba(0,0,0,0.08), 0 4px 6px rgba(0,0,0,0.05);
--shadow-xl:  0 20px 25px rgba(0,0,0,0.1), 0 8px 10px rgba(0,0,0,0.04);
--shadow-2xl: 0 25px 50px rgba(0,0,0,0.15);
```

**원칙**: shadow는 elevation(높이 인식)을 의미. 장식이 아니다.
v1엔 3~4개로 시작. 너무 많으면 인상이 흐려진다.

---

## D. 반응형 브레이크포인트 (4단계 의무)

```css
/* Mobile First */
/* default: 0~639px (mobile) */
@media (min-width: 640px)  { /* sm: tablet 세로 */ }
@media (min-width: 768px)  { /* md: tablet 가로 */ }
@media (min-width: 1024px) { /* lg: desktop */ }
@media (min-width: 1280px) { /* xl: wide */ }
@media (min-width: 1536px) { /* 2xl: ultra-wide */ }
```

**규칙**:
- 모바일 우선 디자인 (default → 큰 화면으로 확장)
- 콘텐츠 최대 너비 1280px (제품 UI) / 1440px (랜딩) 권장
- 4단계 이상 깨짐 없이 동작 의무

---

## 1차 질문 (R3)

```
Q1. 본문 폰트 확정?
A. Pretendard Variable (한글 표준)
B. SUIT Variable (따뜻함)
C. KoPub 돋움 (한국 출판)
D. 기타
이유: 모든 텍스트의 기본
추천: [브랜드 방향 기반]

Q2. 제목 폰트?
A. 본문과 동일 (Pretendard로 통일)
B. Geist (영문 모던)
C. Pretendard Bold/ExtraBold (한글 통일 + 굵기 차이)
D. 기타
이유: 표지·랜딩 임팩트 결정
추천: [...]

Q3. 기본 모서리 반경?
A. 4px (단단함·전문)
B. 8px (모던 표준)
C. 12px (친근함)
D. 16px+ (캐주얼)
이유: 브랜드 인상의 즉시적 신호
추천: [...]

Q4. 한글 본문 라인 높이?
A. 1.5 (영문 표준)
B. 1.625 (한글 권장)
C. 1.75 (매우 여유)
이유: 한글은 1.625 이상이 가독성에 유리
추천: 1.625
```

---

## 출력 (디자인 시스템 §3에 들어감)

```markdown
## 3. Typography Tokens
[폰트 패밀리, 크기, 라인 높이, 자간, 굵기, 스타일 조합]

## 4. Spacing Tokens
[8 베이스 그리드]

## 5. Shape Tokens
[반경, 그림자]

## 6. Breakpoints
[4단계 반응형]
```
