# Design System Output Template

> 5라운드 완료 후 최종 디자인 시스템 마스터 프롬프트.

---

## 파일명

```
design-system-{서비스명}-{YYYYMMDD}.md
```

산출물은 **두 부분**:
1. **마스터 프롬프트** (AI 코드 도구 시스템 프롬프트에 그대로 붙여넣기)
2. **부록** (디자인 토큰 JSON, tailwind.config 매핑 등)

---

## 표준 구조

```markdown
# [서비스명] Design System Master Prompt

> 작성일: YYYY-MM-DD / 버전: v1.0
> 입력: 브랜드 전략서 v[버전]
> 사용처: Claude Code / Cursor / v0 시스템 프롬프트 최상단

---

## 0. 사용법

이 문서를 AI 코드 도구의 시스템 프롬프트 최상단에 그대로 붙여넣어라.
모든 컴포넌트와 페이지 작성 시 이 규칙을 엄격히 준수한다.

## 1. 시각 원칙

- 인상 키워드: [3~5개]
- 톤 매트릭스 위치: [4축]
- 페르소나: [한 줄 의인화]
- 가장 피해야 할 인상 5개: [...] (자세한 안티패턴은 §8 참조)

## 2. Color Tokens

### 2.1 Brand
```css
--color-brand:        #...
--color-brand-hover:  #...
--color-brand-active: #...
--color-brand-bg:     #...
```

### 2.2 Action / Surface / Text / Border / Feedback
(`color-tokens.md` 형식)

### 2.3 다크모드 (지원 시)
(라이트/다크 페어)

### 2.4 Tailwind config 매핑
```js
// tailwind.config.js
module.exports = { theme: { extend: { colors: { ... } } } }
```

## 3. Typography Tokens

- 폰트 패밀리: sans (Pretendard), display (Geist), mono (JetBrains Mono)
- 크기 스케일: xs(12) → 7xl(72)
- 라인 높이: 한글 본문 1.625
- 자간: 본문 0, 큰 제목 -0.03em
- 굵기: thin~black
- 텍스트 스타일 조합: hero, h1~h4, body, caption

## 4. Spacing Tokens
- 8 베이스 그리드: 4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80, 96, 128, 160, 192, 256

## 5. Shape Tokens
- 반경: 0 → 9999 (pill)
- 그림자: sm, md, lg, xl, 2xl
- 기본 반경 결정: [4 / 6 / 8 / 12 / 16+]

## 6. Breakpoints
- mobile: 0~639
- sm: 640~767
- md: 768~1023
- lg: 1024~1279
- xl: 1280~1535
- 2xl: 1536+

## 7. Components (12종)

### 7.1 컴포넌트 매트릭스

| 이름 | variant | size | state |
|---|---|---|---|
| Button | primary, secondary, ghost, destructive, outline | sm, md, lg | hover, active, disabled, loading |
| Input | default | sm, md, lg | focus, error, disabled, success |
| Card | default, elevated | - | - |
| Dialog | default | sm, md, lg | - |
| Badge | default, success, warning, error, info | sm, md | - |
| Toast | success, error, info, warning | - | - |
| Tabs | default, underline | - | - |
| Dropdown | default | - | - |
| Select | default | sm, md, lg | - |
| Switch / Checkbox / Radio | default | sm, md | checked, indeterminate, disabled |
| Avatar | default | xs, sm, md, lg | - |
| Skeleton | default | - | - |

### 7.2 상태 컴포넌트 (5종)
- EmptyState, LoadingState, ErrorState, SuccessState, DisabledState
- 모든 핵심 화면 (FRD에서 정의된 화면) 사용 의무

### 7.3 표준 작성 패턴
```tsx
// cva 사용 예시
const buttonVariants = cva(
  "inline-flex items-center justify-center font-medium transition-colors ...",
  {
    variants: { ... },
    defaultVariants: { variant: "primary", size: "md" }
  }
)
```

## 8. Anti-Patterns ⭐

### 8.1 브랜드 금지 인상 → 코드 규칙 (5개)
- [브랜드 전략 §5.5 변환]
- ...

### 8.2 공통 안티패턴
- ❌ 임의 HEX / 임의 px 사용 금지 (토큰 사용 의무)
- ❌ variant/size 누락
- ❌ Empty/Loading/Error 상태 누락
- ❌ 색 대비 4.5:1 미만
- ❌ 모바일 미테스트
- ❌ shadcn 기본 컬러 그대로 사용
- ❌ AI 느낌 (보라-파란 그라데이션 남발, "혁명" 단어)

## 9. Landing vs Product UI 분리

### 9.1 Landing (마케팅 페이지)
- 최대 너비: 1280~1440px
- 섹션 간격: 96~128px
- 폰트: 히어로 60~72px, 본문 18~20px
- 컬러: 브랜드 컬러 강조 (60~80%)
- 모션: 적극 사용

### 9.2 Product (대시보드)
- 최대 너비: 1280px
- 섹션 간격: 24~48px
- 폰트: 제목 20~24px, 본문 14~16px
- 컬러: 그레이스케일 위주 (60~70%)
- 모션: 최소

## 10. 마스터 프롬프트 결론 (AI 코드 도구용)

```
모든 컴포넌트와 페이지 작성 시 다음을 엄격히 준수해라:

1. 색상: 시맨틱 토큰만 사용 (color-action-primary). HEX 금지.
2. 간격: space-* 토큰만 사용. 임의 px 금지.
3. 컴포넌트: cva 사용 + variant/size prop 의무.
4. 상태: 모든 핵심 화면은 Empty/Loading/Error 정의.
5. 안티패턴 (§8) 금지.
6. Landing vs Product UI는 §9 규칙대로 분리.
7. 반응형: mobile-first, 4단계 의무.
8. 접근성: WCAG AA (대비 4.5:1, 키보드 접근).

이 디자인 시스템의 인상 키워드: [3~5개]
"이렇게 보이면 실패"의 안티패턴: [5개 요약]
```

---

## 다음 단계 입력 요약본 (Handoff Pack)

### 1. 한 줄 정의
[디자인 시스템의 본질을 한 줄로]

### 2. 잠긴 결정
- 컬러 토큰 (Brand/Action/Surface/Text/Border/Feedback) 정의 완료
- 타이포 토큰 (폰트, 크기, 라인 높이) 정의 완료
- 간격·형태 토큰 정의 완료
- 컴포넌트 12종 + 상태 컴포넌트 5종 정의 완료
- 안티패턴 (브랜드 5 + 공통 7+) 정의 완료
- 랜딩 vs 제품 UI 분리 규칙 정의 완료
- 마스터 프롬프트 작성 완료

### 3. 미해결 / 추후 결정
- [다크모드 v1 미지원 시 등 TBD]

### 4. webpage-planner 또는 project-qa에 전달할 변수
- 디자인 시스템 마스터 프롬프트 (이 문서)
- 토큰 JSON (부록 A)
- tailwind.config 매핑 (부록 B)
- 컴포넌트 사용 예시 (부록 C)

### 5. 다음 스킬 호출
다음 단계 후보:
- 웹 페이지 기획 필요: **"페이지 기획해줘"** (webpage-planner)
- 바로 최종 검수: **"최종 검수해줘"** (project-qa)

추가 도움:
- 로고 마크 생성 → logo-prompt-builder
- OG 이미지 생성 → og-image-prompt-builder

---

## 부록 A. 디자인 토큰 JSON

(전체 토큰을 JSON 형식으로 — Figma Tokens Studio 등에서 import 가능)

```json
{
  "color": {
    "brand": { "default": "#...", "hover": "#..." },
    "action": { ... },
    "surface": { ... }
  },
  "spacing": { "1": "4px", "2": "8px", ... },
  "typography": { ... }
}
```

## 부록 B. tailwind.config 완성 매핑

(전체 Tailwind config — 그대로 복사해서 사용 가능)

## 부록 C. 컴포넌트 사용 예시 코드

(Button, Input, Card 등의 실제 사용 코드)
```

---

## 출시 전 체크리스트

- [ ] 모든 토큰이 시맨틱 명명인가?
- [ ] 컬러 대비가 WCAG AA를 충족하는가?
- [ ] 한글 본문 라인 높이가 1.5 이상인가?
- [ ] 모든 컴포넌트에 variant + size가 있는가?
- [ ] Empty/Loading/Error 상태 컴포넌트가 정의됐는가?
- [ ] 안티패턴이 5개 이상인가? ⭐
- [ ] 랜딩 vs 제품 UI 규칙이 분리됐는가?
- [ ] 마스터 프롬프트를 그대로 AI 도구에 붙여넣으면 작동하는가?
- [ ] Tailwind config 매핑이 완성됐는가?

미충족이면 보강 후 핸드오프.
