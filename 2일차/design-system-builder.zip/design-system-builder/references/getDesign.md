# getDesign — 레퍼런스 기반 디자인 토큰 자동 추출

> **역할**: 비개발자·비디자이너 사용자가 좋아하는 사이트(URL 또는 스크린샷)에서
> 디자인 토큰을 자동 추출한다. SKILL.md의 R1·R2에서 호출된다.
>
> **원칙**: 사용자에게 HEX·px·폰트명을 직접 묻지 않는다. 레퍼런스에서 도출 가능한 것은
> 모두 자동 결정한다. 인상·취향만 4지선다로 확인한다.

---

## 사용 시점

design-system-builder의 다음 라운드에서 호출:

- **R1**: 좋아하는 사이트 3~5개 + 싫어하는 사이트 1~3개 수집
- **R2**: 수집된 레퍼런스에서 토큰 v0 자동 생성, 미리보기 확인

---

## 입력 모드 3종 (병렬 사용 가능)

### Mode A. URL 직접 추출 (1순위)

사용자가 사이트 URL을 입력하면 `web_fetch`로 HTML/CSS를 가져와 분석한다.

**추출 가능한 항목:**

| 추출 대상 | 추출 방법 | 신뢰도 |
|---|---|---|
| CSS Custom Properties (`--color-*`, `--font-*`, `--radius-*`) | `<style>` 태그 + 외부 CSS 파싱 | 🟢 높음 |
| 폰트 패밀리 (`@import`, `font-family` 선언) | 정규식 탐색 | 🟢 높음 |
| 인라인 컬러 (`color`, `background`, `border-color`) | HTML 스타일 속성 탐색 | 🟡 중간 |
| 메타 정보 (`theme-color`, og 이미지) | `<meta>` 태그 | 🟢 높음 |
| 모서리 반경 (`border-radius`) | CSS 파싱 | 🟡 중간 |
| 폰트 크기·간격 | CSS 파싱 | 🟡 중간 |
| 컴포넌트 시각 패턴 | HTML 구조 + 클래스명 추정 | 🔴 낮음 |

**추출 알고리즘 (의사코드):**

```
for url in user_urls:
    html = web_fetch(url)
    css_blocks = extract_style_tags(html) + extract_inline_styles(html)
    external_css_urls = extract_link_stylesheets(html)

    custom_props = parse_css_variables(css_blocks)
    fonts = parse_font_family(css_blocks + html)
    colors_used = parse_color_values(css_blocks + html)
    radius_used = parse_border_radius(css_blocks)
    theme_color = parse_meta_theme_color(html)

    record_for_url[url] = {
        custom_props, fonts, colors_used, radius_used, theme_color
    }
```

**한계 명시 (사용자에게 알릴 것):**

- Tailwind JIT, CSS-in-JS (styled-components, emotion) 컴파일 결과물은 추출이 어렵다
- Next.js 등 SSR 사이트의 동적 클래스명은 의미 추론이 어렵다
- iframe, Canvas, SVG 내부 스타일은 별도 처리 필요

이 한계가 발견되면 즉시 **Mode B (스크린샷)** 으로 fallback한다.

### Mode B. 스크린샷 업로드 (Fallback / 보조)

사용자에게 1~3장의 스크린샷 업로드를 요청한다.

**요청 문구 표준:**

```
URL에서 디자인을 충분히 추출하지 못했습니다.
다음 화면을 스크린샷으로 1~3장 올려주시면 더 정확하게 분석할 수 있습니다:

1. 메인 페이지 (히어로 영역이 보이는 부분)
2. 로그인/회원가입 등 폼이 있는 페이지 (선택)
3. 대시보드/콘텐츠 페이지 (선택)

업로드 후 진행하겠습니다.
```

**시각 분석 대상 (멀티모달):**

| 항목 | 판단 기준 | 출력 |
|---|---|---|
| 메인 컬러 | 픽셀 빈도가 가장 높은 채도 있는 색 | HEX 추정 + 컬러 카테고리 |
| 그레이스케일 톤 | 배경·텍스트의 회색 톤 분석 | 차가운/따뜻한/순중성 |
| 폰트 인상 | 글꼴의 형태 (세리프 유무, 굵기, 자간) | 산세리프/세리프/모노 + 한국어 매칭 추천 |
| 모서리 반경 | 버튼·카드의 모서리 형태 | 각짐(0~2)/모던(4~8)/둥금(10~16)/원형 |
| 정보 밀도 | 한 화면당 콘텐츠 양과 여백 비율 | 빽빽/표준/여유 |
| 그림자 인상 | 카드·모달의 그림자 깊이 | 없음/은은/명확/입체 |
| 액센트 색상 | 메인 컬러 외 강조 색상 | 추가 1~2개 |

### Mode C. 사전 카탈로그 매칭 (즉시 적용)

사용자가 언급한 URL이 아래 카탈로그에 있으면 추출 없이 즉시 매칭한다.
정확도가 가장 높다.

```markdown
| 사이트 | 컬러 인상 | 폰트 인상 | 모서리 | 정보 밀도 | 그림자 |
|---|---|---|---|---|---|
| Linear (linear.app) | 보라 액센트 + 다크 모노톤 | Inter, 압축적 | 6~8px | 표준 | 은은 |
| Vercel (vercel.com) | 흑백 강대비 | Geist + Geist Mono | 6~8px | 표준 | 은은 |
| Stripe (stripe.com) | 보라 + 자주 + 그라데이션 | sohne, 모던 | 4~8px | 표준 | 명확 |
| Notion (notion.so) | 베이지 톤 + 흑백 | Inter + 세리프 액센트 | 3~6px | 표준 | 은은 |
| Apple (apple.com) | 순중성 흑백 | SF Pro | 8~12px | 여유 | 명확 |
| Toss (toss.im) | 토스블루 + 모노톤 | Toss Product Sans, Pretendard | 12~16px | 여유 | 명확 |
| Airbnb (airbnb.com) | 코랄핑크 + 모노톤 | Circular, Cereal | 8~12px | 여유 | 명확 |
| Discord (discord.com) | 보라(블러플) + 다크 | gg sans, Whitney | 8px | 표준 | 명확 |
| Figma (figma.com) | 흑백 + 무지개 액센트 | Inter | 6~8px | 표준 | 은은 |
| Anthropic (anthropic.com) | 베이지/세피아 + 흑 | Tiempos, Styrene | 0~2px | 여유 | 없음 |
| OpenAI (openai.com) | 흑백 강대비 | Söhne, ColfaxAI | 4~8px | 여유 | 은은 |
| GitHub (github.com) | 흑백 + 그린 액센트 | Mona Sans | 6~8px | 표준 | 은은 |
| ChatGPT (chatgpt.com) | 흑백 + 그린 액센트 | Söhne | 12~16px | 표준 | 은은 |
| 카카오 (kakao.com) | 카카오 옐로우 + 흑 | KakaoOTF, 산스 | 8~12px | 표준 | 은은 |
| 네이버 (naver.com) | 네이버 그린 | Pretendard, 나눔 | 4~8px | 빽빽 | 은은 |
| 당근마켓 (daangn.com) | 당근 오렌지 | Pretendard | 12~16px | 여유 | 명확 |
| 스타벅스 (starbucks.co.kr) | 스타벅스 그린 + 흑 | Lato, Pretendard | 8~12px | 표준 | 은은 |
| 무신사 (musinsa.com) | 흑백 + 옐로우 액센트 | Pretendard | 0~4px | 빽빽 | 없음 |
| 배달의민족 (baemin.com) | 배민 핑크 + 한나체 | 한나체, Pretendard | 8~12px | 표준 | 은은 |
| Mailchimp (mailchimp.com) | 옐로우 + 흑 | Helvetica, Graphik | 8~12px | 여유 | 명확 |
```

이 카탈로그는 **추가·갱신 가능**한 자산이다. 새로운 사이트가 발견되면 동일 형식으로 추가한다.

---

## 사용자 안내 문구 표준 (비개발자 친화)

### R1 첫 안내 (좋아하는 사이트 수집)

```markdown
디자인 시스템을 만들기 위해 몇 가지 여쭤보겠습니다.
복잡한 수치는 묻지 않으니 편하게 답변해 주세요.

### Q1. 좋아하는 사이트/제품 3~5개를 알려주세요

"이런 느낌으로 만들고 싶다"는 사이트의 URL을 알려주시면 됩니다.
유명한 서비스가 좋아요 (예: Linear, Notion, 토스, 당근, Apple, Stripe 등).

**입력 방법:**
- (A) URL을 그대로 붙여넣기 — `https://linear.app` 같은 형식
- (B) 사이트 이름만 알려주셔도 됩니다 (예: "토스, 노션, 당근")
- (C) 스크린샷 1~3장을 올려주셔도 됩니다 (URL이 없거나 사내 자료일 때)

URL을 받으면 제가 해당 사이트의 색상·폰트·간격 등을 자동으로 추출해서
디자인 시스템 초안을 만들겠습니다.
```

### R1 두 번째 안내 (싫어하는 사이트 수집)

```markdown
### Q2. 반대로 "이렇게는 절대 보이고 싶지 않은" 사이트가 있나요?

브랜드 전략의 "금지 인상"을 코드 규칙으로 변환하기 위해 사용합니다.
1~3개면 충분합니다.

(없으시면 "없음"이라고 답해주셔도 괜찮습니다.
그 경우 브랜드 전략서 §5.5 금지 인상을 그대로 사용합니다.)
```

### R2 안내 (추출 결과 보고)

```markdown
입력하신 [N]개 사이트에서 다음을 추출했습니다:

**공통 패턴:**
- 컬러 톤: [모노톤+보라 액센트 / 강대비 흑백 / ...]
- 폰트 인상: [모던 산세리프 / 세리프 클래식 / ...]
- 모서리: [각짐 / 모던 / 둥금]
- 정보 밀도: [빽빽 / 표준 / 여유]
- 그림자: [없음 / 은은 / 명확 / 입체]

**자동 결정된 디자인 토큰 v0:**
- 메인 컬러: [HEX] — [컬러 인상 한 줄]
- 폰트: 본문 Pretendard / 제목 [Geist 등] / 코드 [JetBrains Mono]
- 모서리 반경: [N]px
- 한글 라인 높이: 1.625 (한글 가독성 기본값)
- 간격: 8px 베이스 그리드 (표준)
- 다크모드: [지원 / v1 미지원]

이대로 진행해도 될까요? 아니면 일부만 조정하시겠어요?
A. ✅ 좋아요, 그대로 진행
B. 색상만 다시 (다른 후보 보여주세요)
C. 모서리만 다시 (좀 더 [각짐/둥금]으로)
D. 폰트만 다시
E. 직접 설명할게요
```

---

## 자동 추출 알고리즘 (통합)

### Step 1. 입력 정규화

```
사용자가 준 입력을 3가지로 분류:
- urls = [https://... 형태 추출]
- names_only = [사이트 이름만 있는 경우. 카탈로그에서 URL 매칭]
- screenshots = [업로드된 이미지 파일들]
```

### Step 2. 모드별 처리

```
for each input in (urls + names_only):
    if input in 사전_카탈로그:
        result = catalog_lookup(input)  # 즉시 매칭, 신뢰도 100%
    else:
        try:
            result = web_fetch_extract(input)
            if extracted_signal_count < 3:
                raise ExtractionWeak
        except (ExtractionFailed, ExtractionWeak):
            result = request_screenshot_fallback(input)

for each screenshot in screenshots:
    result = visual_analyze(screenshot)
```

### Step 3. 통합 (3~5개의 공통점 도출)

```
컬러:
- 빈도 높은 컬러 카테고리 채택
- 충돌 시 (2:3 등) → 사용자에게 확인
- 1개 메인 + 1개 액센트 + 그레이스케일 자동 도출

폰트:
- 한글: Pretendard 기본 (특별 사유 없으면 고정)
- 영문: 레퍼런스 공통점 매칭 (Inter / Geist / Söhne / 자체 폰트 등)
- 모노: 코드 표시가 있는 사이트가 있으면 JetBrains Mono 자동 포함

모서리 반경:
- 평균값 (반올림 4 / 8 / 12 / 16 중 가장 가까운 값)

정보 밀도:
- 다수결 (빽빽/표준/여유)

그림자:
- 평균 깊이
```

### Step 4. 신뢰도 평가

각 추출 결과에 신뢰도 표시:

```
🟢 높음: 사전 카탈로그 매칭 OR CSS 변수 직접 추출 성공
🟡 중간: HTML 파싱으로 추정 OR 스크린샷 시각 분석
🔴 낮음: 1개 사이트만 추출 성공 OR 충돌 발생
```

신뢰도가 **🔴 낮음**이면 사용자에게 추가 입력 요청 (스크린샷 등).

---

## 출력 형식 (R2의 자동 결정 토큰 v0)

```yaml
extraction_summary:
  sources_count: 4
  modes_used: [url, screenshot, catalog]
  confidence: high  # high | medium | low

inferred_tokens:
  brand_color:
    hex: "#2563EB"
    name: "신뢰의 블루"
    inspired_by: ["linear.app", "stripe.com"]

  grayscale_tone: "cool"  # cool | warm | neutral

  fonts:
    sans_ko: "Pretendard Variable"
    sans_en: "Geist"
    mono: "JetBrains Mono"

  radius_base: 8  # px
  radius_inspiration: "모던 표준"

  line_height_body_ko: 1.625
  density: "standard"  # dense | standard | spacious

  shadow_depth: "subtle"  # none | subtle | clear | strong

  dark_mode: true

  anti_patterns_from_dislikes:
    - "정보 밀집 한국 SaaS 인상 (네이버 비즈 페이지 회피)"
    - "..."
```

이 출력은 그대로 다음 라운드(R3 감각 보정, R4 컴포넌트, R5 안티패턴)의 입력으로 들어간다.

---

## Fallback 정책

| 상황 | 대응 |
|---|---|
| 사용자가 URL·이름·스크린샷 셋 다 없음 | 사전 카탈로그 5개를 제시하고 가장 가까운 것 선택 유도 |
| URL 3개 모두 추출 실패 | 스크린샷 업로드 요청. 그래도 안 되면 감각 4지선다 풀세트(기존 R2~R4 방식) |
| 추출 결과가 서로 너무 다름 (충돌) | "이 [N]개 사이트가 분위기가 많이 다른데, 어느 쪽을 더 강하게 살릴까요?" 질문 |
| 사용자가 "잘 모르겠음" | 브랜드 전략서 §5의 인상 키워드만으로 토큰 v0 생성 |

---

## 안전장치

1. **저작권 회피**: 레퍼런스의 디자인 인상·토큰만 추출한다. 특정 컴포넌트의 픽셀 단위 복제·로고·이미지 자산은 절대 추출·복사하지 않는다.

2. **소속 정보 누락**: 추출 과정에서 발견된 사용자명·이메일·개인정보는 즉시 폐기한다.

3. **신뢰도 명시**: 자동 추출 결과는 반드시 신뢰도(🟢🟡🔴)와 함께 사용자에게 보고한다. "AI가 알아서 정했으니 그대로 가세요" 같은 표현 금지.

4. **사용자 거부권**: 어느 단계에서든 "다시 / 직접 정할게요"가 가능하다.

---

## 검증 체크 (이 모듈이 잘 작동하는지)

- [ ] 사용자가 HEX/px/폰트명을 단 한 번도 직접 입력하지 않았는가
- [ ] 추출 결과에 신뢰도가 표시되어 있는가
- [ ] 모든 자동 결정에 "어느 사이트에서 영감을 받았는지" 출처가 있는가
- [ ] 한국 사용자라면 Pretendard 또는 SUIT가 기본 한글 폰트로 잡혔는가
- [ ] 추출 실패 시 스크린샷 fallback 안내가 출력되었는가
- [ ] 미리보기 카드 단계에서 사용자가 시각적으로 확인할 수 있었는가
