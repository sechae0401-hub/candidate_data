# Color Tokens (컬러 토큰 시스템)

> Tailwind CSS 변수 + shadcn/ui 호환. **시맨틱 명명 강제.**

---

## 시맨틱 명명 원칙

### 잘못된 명명 (사용 금지)

```
❌ primary-500, secondary-300, blue-600
   → 의미가 없음. 다크모드/리브랜딩 시 망함.
```

### 올바른 명명 (강제)

```
✅ color-action-primary       (CTA 버튼)
✅ color-action-primary-hover
✅ color-action-secondary
✅ color-action-destructive   (삭제·취소)

✅ color-surface-base         (배경)
✅ color-surface-elevated     (카드)
✅ color-surface-overlay      (모달)

✅ color-text-primary
✅ color-text-secondary
✅ color-text-tertiary
✅ color-text-inverse         (어두운 배경 위 흰 글씨)

✅ color-border-default
✅ color-border-strong

✅ color-feedback-success
✅ color-feedback-warning
✅ color-feedback-error
✅ color-feedback-info
```

원칙: **"무엇을 위한 색인가"** 를 이름에 담는다.

---

## 컬러 시스템 표준 구조

### Brand Colors (브랜드 코어, 1~2개)

```
--color-brand:        [HEX]  /* 메인 브랜드 컬러 */
--color-brand-hover:  [HEX]
--color-brand-active: [HEX]
--color-brand-bg:     [HEX]  /* 옅은 배경용 */
```

### Action Colors (사용자 액션)

```
--color-action-primary:           [HEX]
--color-action-primary-hover:     [HEX]
--color-action-primary-active:    [HEX]
--color-action-primary-disabled:  [HEX]

--color-action-secondary:         [HEX]
--color-action-secondary-hover:   [HEX]

--color-action-destructive:       [HEX]
--color-action-destructive-hover: [HEX]
```

### Surface Colors (배경 계층)

```
--color-surface-base:     [HEX]  /* 페이지 배경 */
--color-surface-elevated: [HEX]  /* 카드, 패널 */
--color-surface-overlay:  [HEX]  /* 모달, 드롭다운 */
--color-surface-inverse:  [HEX]  /* 어두운 섹션 (랜딩 강조) */
```

### Text Colors

```
--color-text-primary:    [HEX]  /* 본문 */
--color-text-secondary:  [HEX]  /* 부가 설명 */
--color-text-tertiary:   [HEX]  /* 캡션, 라벨 */
--color-text-inverse:    [HEX]  /* 어두운 배경 위 */
--color-text-disabled:   [HEX]
--color-text-link:       [HEX]
```

### Border Colors

```
--color-border-default:  [HEX]
--color-border-strong:   [HEX]
--color-border-focus:    [HEX]  /* 포커스 링 */
```

### Feedback Colors

```
--color-feedback-success: [HEX]
--color-feedback-warning: [HEX]
--color-feedback-error:   [HEX]
--color-feedback-info:    [HEX]
```

---

## 컬러 결정 가이드

### Brand Color (메인)

브랜드 전략의 컬러 방향에 따라:

| 방향 | 메인 컬러 HEX 후보 |
|---|---|
| 모노톤 + 액센트 | Black `#0A0A0A` + 액센트 1색 |
| 블루 톤 (신뢰) | `#0066CC` / `#1E40AF` / `#2563EB` |
| 강대비 (흑백) | `#000000` + `#FFFFFF` |
| 그린 톤 (성장) | `#16A34A` / `#22C55E` |
| 베이지/세피아 | `#A8743A` / `#8B6F47` |
| 비비드 | `#FF6B35` / `#FF1493` / `#7C3AED` |

각 후보는 **3~5개 변형** 추천:

```
액센트 블루 1.0
├── --color-action-primary:        #2563EB
├── --color-action-primary-hover:  #1D4ED8  (10% 어둡게)
├── --color-action-primary-active: #1E40AF  (20% 어둡게)
├── --color-action-primary-bg:     #DBEAFE  (옅은 배경)
└── --color-action-primary-fg:     #FFFFFF  (위 글자)
```

### 접근성 (WCAG)

모든 텍스트-배경 조합은 WCAG AA 충족 (대비 4.5:1 이상):
- 본문 (16px+): 4.5:1 이상
- 큰 글씨 (24px+): 3:1 이상

체크 도구: WebAIM Contrast Checker, Stark Figma 플러그인.

---

## 다크모드 (선택)

다크모드 지원 결정:
- 사용자 인식 ON: 거의 모든 SaaS 표준
- v1 부담 OFF: 다크모드 토큰 정의는 v1.x 미룰 수 있음

지원 시 모든 토큰의 다크 페어 정의:

```
:root {
  --color-surface-base: #FFFFFF;
  --color-text-primary: #0A0A0A;
}
[data-theme="dark"] {
  --color-surface-base: #0A0A0A;
  --color-text-primary: #FAFAFA;
}
```

---

## Tailwind 설정 매핑

```js
// tailwind.config.js
module.exports = {
  theme: {
    extend: {
      colors: {
        action: {
          primary: 'var(--color-action-primary)',
          'primary-hover': 'var(--color-action-primary-hover)',
          // ...
        },
        surface: {
          base: 'var(--color-surface-base)',
          elevated: 'var(--color-surface-elevated)',
        },
        text: {
          primary: 'var(--color-text-primary)',
          secondary: 'var(--color-text-secondary)',
        },
        // ...
      }
    }
  }
}
```

사용 예:
```jsx
<button className="bg-action-primary text-white hover:bg-action-primary-hover">
  시작하기
</button>
```

---

## 1차 질문 (R2)

```
Q1. 메인 브랜드 컬러 HEX 1개 확정?
A. [브랜드 방향에 맞는 1번째 후보] - [HEX]
B. [2번째 후보] - [HEX]
C. [3번째 후보] - [HEX]
D. 직접 지정 (HEX 입력)
이유: 시스템 전체의 출발점. 한 번 정하면 토큰 50+개가 자동 도출됨
추천: [...]

Q2. 그레이스케일 톤?
A. 차가운 그레이 (#FAFAFA → #0A0A0A)
B. 따뜻한 그레이 (#FAF8F5 → #1A1614)
C. 순중성 (#FFFFFF → #000000)
이유: 본문·배경 전체의 분위기 결정
추천: [컬러 방향 기반]

Q3. 다크모드 v1 지원?
A. 지원 (토큰 정의 + 토글)
B. 미지원 v1.x (라이트만 v1)
C. 미지원 영구
이유: 토큰 정의량이 2배가 됨. v1엔 부담될 수 있음
추천: [...]
```

---

## 출력 (디자인 시스템 §2에 들어감)

```markdown
## 2. Color Tokens

### 2.1 Brand
[토큰 + HEX]

### 2.2 Action
[토큰 + HEX]

### 2.3 Surface
[토큰 + HEX]

### 2.4 Text
[토큰 + HEX]

### 2.5 Border / Feedback
[토큰 + HEX]

### 2.6 Tailwind config 매핑
(코드 블록)
```
