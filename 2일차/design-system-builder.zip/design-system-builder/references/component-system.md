# Component System (variant + slot 강제)

> 모든 컴포넌트는 variant(상태)와 slot(구성)을 정의한다.
> shadcn/ui 기반.

---

## variant + slot 원칙

### variant (변형 상태)

같은 컴포넌트의 다른 모습. 5종 권장:

```
Button:
- variant: default | primary | secondary | ghost | destructive
- size:    sm | md | lg
- state:   default | hover | active | disabled | loading
```

### slot (구성 부품)

같은 컴포넌트의 영역. 부품별 커스터마이징 가능:

```
Card:
- slot: root | header | title | description | content | footer
```

shadcn/ui 컴포넌트가 이 패턴을 따른다. 새 컴포넌트도 동일 패턴 의무.

---

## 핵심 컴포넌트 12종 (v1 표준)

### 1. Button

```tsx
<Button variant="primary" size="md">시작하기</Button>
<Button variant="secondary" size="sm">취소</Button>
<Button variant="ghost">더 보기</Button>
<Button variant="destructive">삭제</Button>
```

**variant**: `primary`, `secondary`, `ghost`, `destructive`, `outline`
**size**: `sm` (32px), `md` (40px), `lg` (48px)
**state**: hover, active, disabled, loading (스피너 자동)

### 2. Input / Textarea

```tsx
<Input
  label="이메일"
  placeholder="user@example.com"
  error="이미 가입된 이메일입니다"
  state="error"
/>
```

**slot**: label, input, helper, error
**state**: default, focus, error, disabled, success

### 3. Card

```tsx
<Card>
  <CardHeader>
    <CardTitle>제목</CardTitle>
    <CardDescription>부가 설명</CardDescription>
  </CardHeader>
  <CardContent>본문</CardContent>
  <CardFooter>액션</CardFooter>
</Card>
```

**slot**: root, header, title, description, content, footer

### 4. Dialog / Modal

```tsx
<Dialog>
  <DialogTrigger>열기</DialogTrigger>
  <DialogContent>
    <DialogHeader>
      <DialogTitle>제목</DialogTitle>
      <DialogDescription>설명</DialogDescription>
    </DialogHeader>
    <div>본문</div>
    <DialogFooter>
      <Button variant="primary">확인</Button>
    </DialogFooter>
  </DialogContent>
</Dialog>
```

### 5. Badge

**variant**: `default`, `success`, `warning`, `error`, `info`
**size**: `sm`, `md`

### 6. Toast / Notification

**variant**: `success`, `error`, `info`, `warning`
**position**: `top`, `bottom-right` (선택)
**duration**: 기본 4초, 사용자 액션 가능

### 7. Tabs

```tsx
<Tabs defaultValue="overview">
  <TabsList>
    <TabsTrigger value="overview">개요</TabsTrigger>
    <TabsTrigger value="details">상세</TabsTrigger>
  </TabsList>
  <TabsContent value="overview">...</TabsContent>
</Tabs>
```

### 8. Dropdown / Menu

shadcn DropdownMenu 기반. 키보드 접근성 의무.

### 9. Select

shadcn Select 기반. 검색 가능 옵션도 별도 (Combobox).

### 10. Switch / Checkbox / Radio

**state**: checked, unchecked, indeterminate, disabled

### 11. Avatar

**variant**: default, with fallback (이니셜)
**size**: `xs`, `sm`, `md`, `lg`

### 12. Skeleton

로딩 상태용. 모든 핵심 화면이 Skeleton 또는 Spinner 의무 사용.

---

## 상태 패턴 5종 (모든 컴포넌트 공통)

`frd-writer`의 5개 상태와 매핑:

| 상태 | 컴포넌트 처리 |
|---|---|
| **Empty** | EmptyState 컴포넌트 (안내 + CTA) |
| **Loading** | Skeleton 또는 Spinner |
| **Error** | ErrorState 컴포넌트 (메시지 + 재시도) |
| **Success** | 정상 동작 |
| **Disabled** | 흐림 효과 + 안내 메시지 |

각 상태 컴포넌트를 별도 정의:
```tsx
<EmptyState
  icon={Inbox}
  title="아직 프로젝트가 없습니다"
  description="첫 프로젝트를 만들어보세요"
  action={<Button variant="primary">새 프로젝트</Button>}
/>
```

---

## 컴포넌트 작성 표준

```tsx
// components/ui/button.tsx
import { cva, type VariantProps } from "class-variance-authority"

const buttonVariants = cva(
  // 기본 클래스
  "inline-flex items-center justify-center font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-action-primary disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        primary: "bg-action-primary text-white hover:bg-action-primary-hover",
        secondary: "bg-action-secondary text-text-primary hover:bg-action-secondary-hover",
        ghost: "hover:bg-surface-elevated text-text-primary",
        destructive: "bg-action-destructive text-white hover:bg-action-destructive-hover",
        outline: "border border-border-default hover:bg-surface-elevated",
      },
      size: {
        sm: "h-8 px-3 text-sm rounded-md",
        md: "h-10 px-4 text-base rounded-md",
        lg: "h-12 px-6 text-lg rounded-lg",
      },
    },
    defaultVariants: {
      variant: "primary",
      size: "md",
    },
  }
)
```

**원칙**:
- `class-variance-authority` (cva) 사용으로 variant 일관성
- 모든 색상은 토큰 사용 (`bg-action-primary`)
- focus-visible 처리 의무 (접근성)
- disabled 상태 처리 의무

---

## 1차 질문 (R4)

```
Q1. shadcn/ui를 베이스로 사용?
A. ✅ 네 (표준 추천)
B. 별도 컴포넌트 라이브러리 (Mantine, Chakra 등)
C. 직접 구현
이유: shadcn은 복사해서 사용하므로 커스터마이징 자유. v1 표준
추천: shadcn/ui

Q2. v1에 포함할 핵심 컴포넌트?
A. 12종 표준 (Button, Input, Card, Dialog, Badge, Toast, Tabs, Dropdown, Select, Switch, Avatar, Skeleton)
B. 8종 압축 (Button, Input, Card, Dialog, Badge, Toast, Switch, Skeleton)
C. 직접 선택
이유: 컴포넌트 수가 많을수록 일관성 유지 부담 증가
추천: 12종 (대부분 shadcn에서 가져오므로 부담 적음)

Q3. EmptyState / ErrorState 별도 컴포넌트로?
A. ✅ 네 (재사용성, 일관성)
B. 화면마다 직접 처리
이유: 모든 핵심 화면이 Empty/Error 상태를 가지므로 별도 컴포넌트 권장
추천: 네
```

---

## 출력 (디자인 시스템 §7에 들어감)

```markdown
## 7. Components

### 7.1 핵심 컴포넌트 목록 (12종)

| 이름 | variant | size | state |
|---|---|---|---|
| Button | primary, secondary, ghost, destructive, outline | sm, md, lg | hover, active, disabled, loading |
| Input | default | sm, md, lg | default, focus, error, disabled, success |
| Card | default, elevated | - | - |
| ... | ... | ... | ... |

### 7.2 상태 컴포넌트 (5종)
- EmptyState, LoadingState, ErrorState, SuccessState, DisabledState

### 7.3 사용 예시 (코드)
[cva 기반 Button 예시]
```
