# design-system-builder 변경 이력

## v2.0.0 (2026-05-17)

**대규모 재설계 — Progressive Disclosure + AI 코드 도구 호환**

### 구조 변경
- SKILL.md 슬림화 (이전 281줄 → 약 60줄)
- 상세 내용을 `references/` 6개 파일로 분리
- `feedback/` 폴더 신설
- 죽은 링크 "landing-design-builder" 제거 (이제 webpage-planner가 처리)

### 신규 references/ 파일
- `handoff-mapping.md` — 브랜드 전략 → 디자인 시스템 매핑
- `color-tokens.md` — 시맨틱 명명 강제 + Tailwind 매핑
- `typography-spacing.md` — 한글 우선 타이포 + 8 베이스 그리드
- `component-system.md` — 12종 컴포넌트 + 5상태 + cva 패턴
- `anti-patterns.md` — 금지 인상 → 코드 규칙 변환
- `output-template.md` — 마스터 프롬프트 + 부록 (토큰 JSON, Tailwind config)
- `domain-rules.md` — 10개 강제 규칙

### 핵심 신규/강화 규칙
- D1. AI 코드 도구 호환 형식 의무 (Claude Code / Cursor 직접 입력)
- D2. 시맨틱 토큰 강제 (primary-500 같은 명명 거부)
- D3. variant + slot 의무
- D4. 랜딩 vs 제품 UI 분리 강제
- D5. 금지 인상 → 안티패턴 변환 의무
- D8. 한글 타이포 우선 (라인 높이 1.625, 자간 보정)
- D9. frontend-design 공식 스킬 참조 권장

### 핸드오프 정합성
- 입력: brand-strategy의 브랜드 전략서
- 출력: webpage-planner(옵션) 또는 project-qa 입력

---

## 향후 버전 관리

- Major: 워크플로우 변경
- Minor: 컴포넌트 추가
- Patch: 안티패턴 보강, 예시 추가
